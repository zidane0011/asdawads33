import Layout from './Layout';
import Home from './pages/Home'
import { BrowserRouter, Routes, Route } from "react-router";
import { QueryClientProvider, QueryClient } from '@tanstack/react-query'
import { AuthProvider } from './hooks/useAuth'
import { LoginModalProvider } from './hooks/useLoginModal'
import { ThemeProvider } from './hooks/useTheme'
import { SocketProvider } from './hooks/SocketProvider'
import './App.css'
import Slot from './pages/Slot';
import Casino from './pages/Casino';
import Minigame from './pages/Minigame';
import Sports from './pages/Sports';
import GameDetail from './pages/GameDetail';

const queryClient = new QueryClient()

function App() {

  return (
    <>
      <QueryClientProvider client={queryClient}>
        <ThemeProvider>
        <AuthProvider>
          <SocketProvider>
            <LoginModalProvider>
              <BrowserRouter>
                <Routes>
                  <Route path="/" element={<Layout />}>
                    <Route path="/" element={<Home />} />
                    <Route path="/slots" element={<Slot />} />
                    <Route path="/casino" element={<Casino />} />
                    <Route path="/minigame" element={<Minigame />} />
                    <Route path="/sports" element={<Sports />} />
                    <Route path="/game" element={<GameDetail />} />
                  </Route>
                </Routes>
              </BrowserRouter>
            </LoginModalProvider>
          </SocketProvider>
        </AuthProvider>
        </ThemeProvider>
      </QueryClientProvider>
    </>
  )
}

export default App
