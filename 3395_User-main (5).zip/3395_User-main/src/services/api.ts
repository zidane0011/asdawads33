export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'https://api.bet-30.pro';

export const SOCKET_SERVICE_URL = import.meta.env.VITE_SOCKET_SERVICE_URL ?? 'wss://api.bet-30.pro';
export const SOCKET_CLIENT_CHANNEL = 'bronco-client';

export const GameType = {
  LIVECASINO: 1,
  SLOT: 2,
  MINIGAME: 3,
  FISHING: 4,
  SPORTS: 5,
} as const;

export type GameType = typeof GameType[keyof typeof GameType];

export interface LoginRequest {
  loginId: string;
  password: string;
}

export interface LoginResponse {
  status: string;
  message: string;
  data: {
    access_token: string;
    profile: {
      avatar: string;
      firstName: string;
      lastName: string;
      email: string;
      phoneNumber: string;
      loginId: string;
      balance: string;
    };
  };
}

export interface ProfileResponse {
  status: string;
  message: string;
  data: {
    avatar: string;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    loginId: string;
    balance: string;
  } | null;
}

export interface ProfileChangeRequest {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  password: string;
}

export interface ProfileChangeResponse {
  status: string;
  message: string;
  data: null;
}

export interface PasswordChangeRequest {
  password: string;
}

export interface PasswordChangeResponse {
  status: string;
  message: string;
  data: null;
}

export interface ApiError {
  status?: string;
  message?: string;
  error?: string;
}

export interface Provider {
  _id: string;
  vendorCode: string;
  name: string;
  launch_enable: boolean;
  thumbnail: string;
  type: number;
  sequence: number;
  game_source: string;
  __v: number;
  createdAt: string;
  updatedAt: string;
}

export interface ProvidersRequest {
  type: GameType;
}

export interface ProvidersResponse {
  status: string;
  message: string;
  data: {
    providers: Provider[];
    totalCount: number;
  };
}

export interface Game {
  _id: string;
  vendorCode: string;
  provider: string;
  gameId: string;
  gameCode: string;
  gameName: string;
  slug: string;
  thumbnail: string;
  launch_enable: boolean;
  isNew: boolean;
  underMaintenance: boolean;
  is_maindisplay: boolean;
  is_exclusive: boolean;
  is_featured: boolean;
  is_joker: boolean;
  is_classic: boolean;
  sequence: number;
  type: number;
  game_source: string;
  __v: number;
  updatedAt: string;
}

export interface SlotGamesListRequest {
  search?: string;
  vendorCode?: string[];
  type: number;
  page: number;
  limit: number;
}

export interface SlotGamesListResponse {
  status: string;
  message: string;
  data: {
    data: Game[];
    totalCount: number;
  };
}

export interface SlotGamesWholeRequest {
  type: number;
  limit: number;
}

export interface SlotGamesWholeResponse {
  status: string;
  message: string;
  data: {
    data: Array<{
      vendorCode: string;
      games: Game[];
    }>;
  };
}

export interface EnterGameRequest {
  game_code: string;
  vendor_code: string;
}

export interface EnterGameResponse {
  status: string;
  message: string;
  data: {
    game_url: string;
  } | null;
}


export interface ThemeResponse {
  status: string;
  message: string;
  data: {
    theme: number;
  };
}

export interface GameHistoryRequest {
  search: string;
  fromDate: string;
  toDate: string;
  status: number;
  page: number;
  limit: number;
}

export interface GameHistoryItem {
  _id?: string;
  id?: string;
  gameName?: string;
  game_name?: string;
  provider?: string;
  vendorCode?: string;
  bet?: string | number;
  win?: string | number;
  amount?: string | number;
  result?: string | number;
  status?: number;
  createdAt?: string;
  created_at?: string;
  date?: string;
  time?: string;
  [key: string]: any;
}

export interface GameHistoryResponse {
  status: string;
  message: string;
  data: {
    data: GameHistoryItem[];
    totalCount?: number;
    total?: number;
  };
}

export interface TransactionHistoryRequest {
  fromDate: string;
  toDate: string;
  type: number;
  page: number;
  limit: number;
}

export interface TransactionHistoryItem {
  _id?: string;
  id?: string;
  type?: string;
  transaction_type?: string;
  amount?: string | number;
  fromBalance?: string | number;
  from_balance?: string | number;
  toBalance?: string | number;
  to_balance?: string | number;
  createdAt?: string;
  created_at?: string;
  date?: string;
  time?: string;
  [key: string]: any;
}

export interface TransactionHistoryResponse {
  status: string;
  message: string;
  data: {
    data: TransactionHistoryItem[];
    totalCount?: number;
    total?: number;
  };
}

class ApiService {
  private getAuthToken(): string | null {
    return localStorage.getItem('access_token');
  }

  private async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const url = `${API_BASE_URL}${endpoint}`;
    const token = this.getAuthToken();

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>),
    };

    if (token) {
      headers['Authorization'] = `Bearer ${token}`;
    }

    const response = await fetch(url, {
      ...options,
      headers,
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json().catch(() => ({
        message: 'An error occurred',
      }));
      throw new Error(errorData.message || errorData.error || 'Request failed');
    }

    return response.json();
  }

  async login(credentials: LoginRequest): Promise<LoginResponse> {
    return this.request<LoginResponse>('/api/user/auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    });
  }

  async logout(): Promise<void> {
    await this.request('/api/user/auth/logout', {
      method: 'GET',
    });
  }

  async verify(): Promise<{ status: string; message: string }> {
    return this.request('/api/user/auth/verify', {
      method: 'GET',
    });
  }

  async getProfile(): Promise<ProfileResponse> {
    return this.request<ProfileResponse>('/api/user/auth/profile', {
      method: 'GET',
    });
  }

  async changeProfile(request: ProfileChangeRequest): Promise<ProfileChangeResponse> {
    return this.request<ProfileChangeResponse>('/api/user/auth/profile/change', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async changePassword(request: PasswordChangeRequest): Promise<PasswordChangeResponse> {
    return this.request<PasswordChangeResponse>('/api/user/auth/profile/password', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async getProviders(type: GameType): Promise<ProvidersResponse> {
    return this.request<ProvidersResponse>(`/api/user/slot/providers?type=${type}`, {
      method: 'GET',
    });
  }

  async getSlotGames(request: SlotGamesListRequest): Promise<SlotGamesListResponse> {
    return this.request<SlotGamesListResponse>('/api/user/slot/list', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async getHomeGames(type: number): Promise<SlotGamesListResponse> {
    return this.request<SlotGamesListResponse>('/api/user/slot/list/home', {
      method: 'POST',
      body: JSON.stringify({ type }),
    });
  }

  async getSlotGamesWhole(request: SlotGamesWholeRequest): Promise<SlotGamesWholeResponse> {
    return this.request<SlotGamesWholeResponse>('/api/user/slot/list/whole', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async enterGame(request: EnterGameRequest): Promise<EnterGameResponse> {
    const params = new URLSearchParams({
      game_code: request.game_code,
      vendor_code: request.vendor_code,
    });
    return this.request<EnterGameResponse>(`/api/user/slot/enter?${params.toString()}`, {
      method: 'GET',
    });
  }

  async enterSports(): Promise<{ code: number; message: string; data: { gameUrl: string } }> {
    return this.request<{ code: number; message: string; data: { gameUrl: string } }>('/api/user/sports/enter', {
      method: 'GET',
    });
  }

  async getTheme(): Promise<ThemeResponse> {
    return this.request<ThemeResponse>('/api/user/auth/theme', {
      method: 'GET',
    });
  }

  async getGameHistory(request: GameHistoryRequest): Promise<GameHistoryResponse> {
    return this.request<GameHistoryResponse>('/api/user/log/list', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }

  async getTransactionHistory(request: TransactionHistoryRequest): Promise<TransactionHistoryResponse> {
    return this.request<TransactionHistoryResponse>('/api/user/log/transaction', {
      method: 'POST',
      body: JSON.stringify(request),
    });
  }
}

export const apiService = new ApiService();
