export const SocketMessageCode = {
  HeartBeat: 0,
  CATEOGRY: 100,
  PREMATCH_FIXTURE: 101,
  PREMATCH_LIVE_SCORE: 102,
  PREMATCH_MARKET: 103,
  INPLAY_FIXTURE: 201,
  INPLAY_LIVE_SCORE: 202,
  INPLAY_MARKET: 203,
  DEPOSIT: 301,
  WITHDRAW: 302,
  USER_CASH: 400,
  USER_CASINO: 401,
  USER_POINT: 402,
  LOG_OUT: 900,
} as const;

export type SocketMessageCodeType = (typeof SocketMessageCode)[keyof typeof SocketMessageCode];

export interface SocketMessageType {
  code: SocketMessageCodeType;
  body: Record<string, unknown>;
}
