import { useState, useEffect } from "react";

const CasinoHero = () => {
  const images = [
    "https://assets.a7a.info/templates/bet30/images/live-casino-slider/1.jpeg",
    "https://assets.a7a.info/templates/bet30/images/live-casino-slider/2.jpeg",
    "https://assets.a7a.info/templates/bet30/images/live-casino-slider/3.jpeg",
    "https://assets.a7a.info/templates/bet30/images/live-casino-slider/4.jpeg",
  ];

  const [currentIndex, setCurrentIndex] = useState(0);

  // Auto-play slider
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    }, 5000); // Change slide every 5 seconds

    return () => clearInterval(interval);
  }, [images.length]);

  return (
    <section className="relative w-full overflow-hidden">
      <div className="relative w-full">
        {/* Images Container */}
        <div className="relative w-full flex" style={{ transform: `translateX(-${currentIndex * 100}%)`, transition: 'transform 0.5s ease-in-out' }}>
          {images.map((image, index) => (
            <div
              key={index}
              className="relative flex-shrink-0 w-full"
            >
              <img
                src={image}
                alt={`Slide ${index + 1}`}
                className="w-full h-auto object-contain"
                style={{ aspectRatio: 'auto' }}
              />
            </div>
          ))}
        </div>
        {/* Bottom Gradient Overlay */}
        <div className="absolute bottom-0 left-0 right-0 h-[5%] bg-gradient-to-t from-[var(--bg-primary)] via-[var(--bg-primary)]/80 to-transparent pointer-events-none z-10"></div>
      </div>
    </section>
  );
};

export default CasinoHero;



