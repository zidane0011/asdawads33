import { useState } from "react";
import { 
  Sparkles, Flame, Heart, Zap, Cherry, 
  Trophy, Star, Clock, TrendingUp, Gamepad2,
  Dice6, Coins, Crown, Target, Award
} from "lucide-react";
import { Search } from "lucide-react";
import { useDragScroll } from "@/hooks/useDragScroll";
import { useTheme } from "@/hooks/useTheme";

interface SearchGamesProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const SearchGames = ({ searchQuery, onSearchChange }: SearchGamesProps) => {
  const [selectedCategory, setSelectedCategory] = useState("Todos");
  const [localSearch, setLocalSearch] = useState(searchQuery);
  const dragScrollRef = useDragScroll();
  const { themeConfig } = useTheme();

  const handleSearch = () => {
    onSearchChange(localSearch);
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSearch();
    }
  };

  const categories = [
    { id: "Top", label: "Top", icon: Sparkles },
    { id: "Todos", label: "Todos", icon: Flame },
    { id: "Favoritos", label: "Favoritos", icon: Heart },
    { id: "Nuevos", label: "Nuevos", icon: Zap },
    { id: "Slots", label: "Slots", icon: Cherry },
    { id: "Popular", label: "Popular", icon: TrendingUp },
    { id: "Recomendados", label: "Recomendados", icon: Star },
    { id: "Recientes", label: "Recientes", icon: Clock },
    { id: "Premios", label: "Premios", icon: Trophy },
    { id: "Jackpot", label: "Jackpot", icon: Crown },
    { id: "Clasicos", label: "Clasicos", icon: Dice6 },
    { id: "Frutas", label: "Frutas", icon: Cherry },
    { id: "Aventura", label: "Aventura", icon: Gamepad2 },
    { id: "Multiplicadores", label: "Multiplicadores", icon: Coins },
    { id: "Megaways", label: "Megaways", icon: Target },
    { id: "VIP", label: "VIP", icon: Award },
  ];

  return (
    <section className="w-full bg-theme-primary">
      <div className="px-4 py-2">
        

        <div className="flex flex-col md:flex-row items-center justify-between gap-4 flex-wrap">
          {/* Category Part */}
          <div ref={dragScrollRef} className="flex items-end gap-2 overflow-x-auto pb-2 md:custom-scrollbar scrollbar-hide-mobile flex-1 min-w-0 pt-2 w-full md:w-auto">
            {categories.map((category) => {
              const Icon = category.icon;
              const isSelected = selectedCategory === category.id;
              
              return (
                <div key={category.id} className="relative flex-shrink-0">
                  <button
                    onClick={() => setSelectedCategory(category.id)}
                    className={`
                      flex items-center gap-2 px-4 py-2 rounded-full border font-medium text-sm whitespace-nowrap w-auto h-10 md:h-12
                      transition-all duration-200 relative
                      ${
                        isSelected
                          ? "shadow-md border-none"
                          : "hover:border-[#3b82f6]"
                      }
                    `}
                    style={isSelected ? {
                      backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
                      color: themeConfig?.header.selectedTextColor || '#ffffff',
                    } : {
                      backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                      borderColor: themeConfig?.header.borderColor || '#27287e',
                      color: themeConfig?.header.textColor || '#ffffff',
                    }}
                  >
                    <Icon className="w-4 h-4" strokeWidth={2} fill="none" />
                    <span>{category.label}</span>
                  </button>
                </div>
              );
            })}
          </div>

          {/* Search Part - Desktop */}
          <div className="hidden md:flex items-center gap-2 flex-shrink-0">
            {/* Search Input */}
            <div className="relative flex items-center">
              <div className="absolute left-3 pointer-events-none flex items-center gap-2">
                <Search className="w-4 h-4 text-gray-400" strokeWidth={2} fill="none" />
              </div>
              <input
                type="text"
                placeholder="Busqueda"
                value={localSearch}
                onChange={(e) => setLocalSearch(e.target.value)}
                onKeyPress={handleKeyPress}
                className="
                  pl-10 pr-4 py-2 w-40 sm:w-64 h-10 md:h-12
                  rounded-full
                  placeholder-gray-400 placeholder:text-xs sm:placeholder:text-sm
                  focus:outline-none border 
                  transition-colors
                "
                style={{
                  backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                  borderColor: themeConfig?.header.borderColor || '#27287e',
                  color: themeConfig?.header.textColor || '#ffffff',
                }}
              />
            </div>

            {/* Search Button */}
            <button 
              onClick={handleSearch}
              className="px-3 sm:px-6 h-10 md:h-12 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-lg whitespace-nowrap text-center"
              style={{
                backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
                color: themeConfig?.header.selectedTextColor || '#ffffff',
              }}
              onMouseEnter={(e) => {
                const from = themeConfig?.gradient.from || '#940000';
                const to = themeConfig?.gradient.to || '#ca8005';
                // Slightly brighter on hover
                e.currentTarget.style.backgroundImage = `linear-gradient(to right, ${from}, ${to})`;
                e.currentTarget.style.filter = 'brightness(1.1)';
              }}
              onMouseLeave={(e) => {
                const from = themeConfig?.gradient.from || '#940000';
                const to = themeConfig?.gradient.to || '#ca8005';
                e.currentTarget.style.backgroundImage = `linear-gradient(to right, ${from}, ${to})`;
                e.currentTarget.style.filter = 'brightness(1)';
              }}
            >
              Buscar
            </button>
          </div>

          {/* Search Part - Show first on mobile */}
        <div className="flex items-center gap-2 mb-4 md:mb-0 md:hidden w-full">
          {/* Search Input */}
          <div className="relative flex items-center flex-1">
            <div className="absolute left-3 pointer-events-none flex items-center gap-2">
              <Search className="w-4 h-4 text-gray-400" strokeWidth={2} fill="none" />
            </div>
            <input
              type="text"
              placeholder="Busqueda"
              value={localSearch}
              onChange={(e) => setLocalSearch(e.target.value)}
              onKeyPress={handleKeyPress}
              className="
                pl-10 pr-4 py-2 w-full h-10
                rounded-full
                placeholder-gray-400 placeholder:text-xs sm:placeholder:text-sm
                focus:outline-none focus:border-[#3b82f6] focus:ring-1 focus:ring-[#3b82f6]
                transition-colors
              "
              style={{
                backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                borderColor: themeConfig?.header.borderColor || '#27287e',
                color: themeConfig?.header.textColor || '#ffffff',
              }}
            />
          </div>

          {/* Search Button */}
          <button 
            onClick={handleSearch}
            className="px-4 h-10 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-lg whitespace-nowrap flex-shrink-0 w-1/4"
            style={{
              backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
              color: themeConfig?.header.selectedTextColor || '#ffffff',
            }}
            onMouseEnter={(e) => {
              const from = themeConfig?.gradient.from || '#940000';
              const to = themeConfig?.gradient.to || '#ca8005';
              e.currentTarget.style.backgroundImage = `linear-gradient(to right, ${from}, ${to})`;
              e.currentTarget.style.filter = 'brightness(1.1)';
            }}
            onMouseLeave={(e) => {
              const from = themeConfig?.gradient.from || '#940000';
              const to = themeConfig?.gradient.to || '#ca8005';
              e.currentTarget.style.backgroundImage = `linear-gradient(to right, ${from}, ${to})`;
              e.currentTarget.style.filter = 'brightness(1)';
            }}
          >
            Buscar
          </button>
        </div>
        </div>

      </div>
    </section>
  );
};

export default SearchGames;

