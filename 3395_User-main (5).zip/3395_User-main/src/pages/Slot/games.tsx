import { useState, useEffect, useRef } from "react";
import { useSearchParams } from "react-router-dom";
import GameCard from "@/components/gamecard";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { apiService, type Game } from "@/services/api";
import { useTheme } from "@/hooks/useTheme";

interface SlotGamesProps {
  search?: string;
  vendorCode?: string | null;
  gameType?: number;
}

const SlotGames = ({ search = "", vendorCode = null, gameType = 2 }: SlotGamesProps) => {
  const [searchParams] = useSearchParams();
  const viewParam = searchParams.get('view');
  const [games, setGames] = useState<Game[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const gamesPerPage = 20;
  const { themeConfig } = useTheme();
  
  // Cache to prevent duplicate API calls
  const gamesCacheRef = useRef<{ 
    data: Game[] | null; 
    timestamp: number; 
    page: number; 
    search: string; 
    vendorCode: string | null;
    gameType: number;
    view: string | null;
  } | null>(null);
  const CACHE_DURATION = 5000; // 5 seconds cache
  const hasFetchedRef = useRef(false);
  const currentFetchRef = useRef<string>('');

  useEffect(() => {
    const fetchGames = async () => {
      // Create a unique key for this fetch based on dependencies
      const fetchKey = `${vendorCode}-${gameType}-${search}-${currentPage}-${viewParam}`;
      
      // Check cache first
      const cache = gamesCacheRef.current;
      if (
        cache &&
        Date.now() - cache.timestamp < CACHE_DURATION &&
        cache.page === currentPage &&
        cache.search === search &&
        cache.vendorCode === vendorCode &&
        cache.gameType === gameType &&
        cache.view === viewParam
      ) {
        if (cache.data) {
          setGames(cache.data);
          return;
        }
      }

      // Skip if already fetching the same request
      if (hasFetchedRef.current && currentFetchRef.current === fetchKey) {
        return;
      }

      hasFetchedRef.current = true;
      currentFetchRef.current = fetchKey;
      setError(null);

      try {
        // Map view params to vendor codes
        const viewVendorMap: Record<string, string[]> = {
          'pragmatic': ['pragmatic'],
          'rubyplay': ['slot-rubyplay'],
          'kagaming': ['slot-ka'],
        };

        let response;
        
        // Determine which API to use based on the case
        if (viewParam === 'top' && !search && !vendorCode) {
          // Coming from "Ver más" in top section - use /api/user/slot/list/home
          response = await apiService.getHomeGames(1);
        } else if (viewParam && viewVendorMap[viewParam] && !search && !vendorCode) {
          // Coming from "Ver más" in vendor section - use /api/user/slot/list with specific vendor
          response = await apiService.getSlotGames({
            search: "",
            vendorCode: viewVendorMap[viewParam],
            type: 2,
            page: currentPage,
            limit: gamesPerPage,
          });
        } else if (!search && !vendorCode) {
          // No search, no vendorCode - use getSlotGamesWhole
          response = await apiService.getSlotGamesWhole({
            type: gameType,
            limit: gamesPerPage,
          });
        } else {
          // Use the regular API for filtered searches
          const vendorCodeArray = vendorCode ? [vendorCode] : [];
          response = await apiService.getSlotGames({
            search: search || "",
            vendorCode: vendorCodeArray,
            type: gameType,
            page: currentPage,
            limit: gamesPerPage,
          });
        }

        // Process response
        if (response.status === 'ok' && response.data) {
          let enabledGames: Game[];

          if (viewParam === 'top' || (viewParam && viewVendorMap[viewParam]) || search || vendorCode) {
            // Regular list API response (SlotGamesListResponse)
            const listResponse = response as { status: string; message: string; data: { data: Game[]; totalCount: number } };
            enabledGames = listResponse.data.data.filter(game => game.launch_enable);
            const totalCount = listResponse.data.totalCount;
            setTotalPages(Math.ceil(totalCount / gamesPerPage));
          } else {
            // Whole API response (SlotGamesWholeResponse) - flatten games from all vendors
            const wholeResponse = response as { status: string; message: string; data: { data: Array<{ vendorCode: string; games: Game[] }> } };
            const allGames = wholeResponse.data.data.flatMap(vendor => vendor.games);
            enabledGames = allGames.filter(game => game.launch_enable);
            setTotalPages(1);
          }

          setGames(enabledGames);
          
          // Update cache
          gamesCacheRef.current = {
            data: enabledGames,
            timestamp: Date.now(),
            page: currentPage,
            search: search,
            vendorCode: vendorCode,
            gameType: gameType,
            view: viewParam,
          };
        } else {
          setError(response.message || 'Failed to load games');
        }
      } catch (err: any) {
        setError(err.message || 'Failed to load games');
        console.error('Error fetching games:', err);
      } finally {
        // Only reset if this is still the current fetch
        if (currentFetchRef.current === fetchKey) {
          hasFetchedRef.current = false;
          currentFetchRef.current = '';
        }
      }
    };

    fetchGames();
  }, [currentPage, search, vendorCode, gameType, viewParam]);

  // Reset to page 1 when search, vendorCode, gameType, or view changes
  useEffect(() => {
    setCurrentPage(1);
  }, [search, vendorCode, gameType, viewParam]);

  const handlePageChange = (page: number) => {
    if (page >= 1 && page <= totalPages) {
      setCurrentPage(page);
      // Scroll to top of games section
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  // Pagination component
  const PaginationControls = () => {
    if (totalPages <= 1) return null;

    return (
      <div className="flex items-center justify-center gap-1 md:gap-2">
        {/* Previous Button */}
        <button
          onClick={() => handlePageChange(currentPage - 1)}
          disabled={currentPage === 1}
          className={`
            px-2 py-1 md:px-4 md:py-2 rounded-lg border font-medium text-xs md:text-sm transition-all duration-200
            flex items-center gap-1
            ${
              currentPage === 1
                ? "text-gray-500 cursor-not-allowed"
                : "text-white hover:border-[#3b82f6]"
            }
          `}
          style={{
            backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
            borderColor: themeConfig?.header.borderColor || '#27287e',
          }}
        >
          <ChevronLeft className="w-3 h-3 md:w-4 md:h-4" />
        </button>

        {/* Page Numbers */}
        <div className="flex items-center gap-1 md:gap-2">
          {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => {
            // Show first page, last page, current page, and pages around current
            if (
              page === 1 ||
              page === totalPages ||
              (page >= currentPage - 1 && page <= currentPage + 1)
            ) {
              return (
                <button
                  key={page}
                  onClick={() => handlePageChange(page)}
                  className={`
                    w-8 h-8 md:w-10 md:h-10 rounded-lg border font-medium text-xs md:text-sm transition-all duration-200
                    ${
                      currentPage === page
                        ? "text-white shadow-md border-none"
                        : "text-white hover:border-[#3b82f6]"
                    }
                  `}
                  style={currentPage === page ? {
                    backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
                  } : {
                    backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                    borderColor: themeConfig?.header.borderColor || '#27287e',
                  }}
                >
                  {page}
                </button>
              );
            } else if (
              page === currentPage - 2 ||
              page === currentPage + 2
            ) {
              return (
                <span key={page} className="text-white px-1 md:px-2 text-xs md:text-sm">
                  ...
                </span>
              );
            }
            return null;
          })}
        </div>

        {/* Next Button */}
        <button
          onClick={() => handlePageChange(currentPage + 1)}
          disabled={currentPage === totalPages}
          className={`
            px-2 py-1 md:px-4 md:py-2 rounded-lg border font-medium text-xs md:text-sm transition-all duration-200
            flex items-center gap-1
            ${
              currentPage === totalPages
                ? "text-gray-500 cursor-not-allowed"
                : "text-white hover:border-[#3b82f6]"
            }
          `}
          style={{
            backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
            borderColor: themeConfig?.header.borderColor || '#27287e',
          }}
        >
          <ChevronRight className="w-3 h-3 md:w-4 md:h-4" />
        </button>
      </div>
    );
  };

  return (
    <section className="py-6 px-4 bg-theme-primary">
      {/* Pagination - Above */}
      {totalPages > 1 && (
        <div className="mb-6">
          <PaginationControls />
        </div>
      )}

      

      {/* Error State */}
      {error && (
        <div className="text-center py-12">
          <p className="text-red-400 text-sm">{error}</p>
        </div>
      )}

      {/* Games Grid */}
            <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 xl:grid-cols-8 gap-2 sm:gap-4 mb-6">
              {games.map((game) => (
                <GameCard 
                  key={game._id} 
                  title={game.gameName} 
                  imageUrl={game.thumbnail} 
                  gameCode={game.gameCode}
                  vendorCode={game.vendorCode}
                />
              ))}
            </div>

      {/* Pagination - Below */}
      {totalPages > 1 && (
        <div className="mt-6">
          <PaginationControls />
        </div>
      )}
    </section>
  );
};

export default SlotGames;
