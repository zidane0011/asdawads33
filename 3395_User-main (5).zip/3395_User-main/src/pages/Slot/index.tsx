import { useState, useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import { apiService } from "@/services/api";
import SlotHero from "./slothero";
import CasinoHero from "./casinohero";
import SlotProviders from "./slotproviders";
import SlotGames from "./games";
import SearchGames from "./gamesearch";

interface SlotProps {
  gameType?: number; // Default to 2 for slots, 1 for casino
}

function Slot({ gameType = 2 }: SlotProps) {
  const [searchParams] = useSearchParams();
  const viewParam = searchParams.get('view');
  const vendorParam = searchParams.get('vendor');

  // Map view params to vendor codes
  const viewVendorMap: Record<string, string> = {
    'pragmatic': 'pragmatic',
    'rubyplay': 'slot-rubyplay',
    'kagaming': 'slot-ka',
  };

  // Initialize vendor code immediately from URL params
  const getInitialVendorCode = () => {
    if (viewParam && viewVendorMap[viewParam]) {
      return viewVendorMap[viewParam];
    } else if (vendorParam) {
      return vendorParam;
    }
    return null;
  };

  const [searchQuery, setSearchQuery] = useState("");
  const [selectedVendorCode, setSelectedVendorCode] = useState<string | null>(() => getInitialVendorCode());
  const [providerGameType, setProviderGameType] = useState<number | null>(null);

  // Set initial vendor code based on view param or vendor param
  useEffect(() => {
    const initialVendor = getInitialVendorCode();
    if (initialVendor) {
      setSelectedVendorCode(initialVendor);
      
      // Fetch provider info to get its gameType
      const fetchProviderType = async () => {
        try {
          // Try both slot and casino types to find the provider
          const [slotResponse, casinoResponse] = await Promise.all([
            apiService.getProviders(2), // SLOT
            apiService.getProviders(1), // LIVECASINO
          ]);
          
          const allProviders = [
            ...(slotResponse.status === 'ok' && slotResponse.data ? slotResponse.data.providers : []),
            ...(casinoResponse.status === 'ok' && casinoResponse.data ? casinoResponse.data.providers : []),
          ];
          
          const provider = allProviders.find((p: { vendorCode: string }) => p.vendorCode === initialVendor);
          if (provider) {
            setProviderGameType(provider.type);
          }
        } catch (err) {
          console.error('Error fetching provider type:', err);
        }
      };
      fetchProviderType();
    }
  }, [viewParam, vendorParam]);

  return (
    <div className="flex flex-col">
      {gameType === 1 || gameType === 3 ? <CasinoHero /> : <SlotHero />}
      <SlotProviders 
        gameType={gameType}
        onVendorSelect={setSelectedVendorCode}
        initialVendorCode={viewParam && viewVendorMap[viewParam] ? viewVendorMap[viewParam] : vendorParam}
      />
      <SearchGames 
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
      />
      <SlotGames 
        search={searchQuery}
        vendorCode={selectedVendorCode}
        gameType={providerGameType !== null ? providerGameType : gameType}
      />
    </div>
  )
}

export default Slot
