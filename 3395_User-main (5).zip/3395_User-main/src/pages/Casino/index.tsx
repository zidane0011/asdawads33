import Slot from "../Slot";

function Casino() {
  // Casino uses type: 1, Slot uses type: 2
  return <Slot gameType={1} />;
}

export default Casino;

