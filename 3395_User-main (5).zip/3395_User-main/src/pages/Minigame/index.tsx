import Slot from "../Slot";

function Minigame() {
  // Minigame uses type: 3 (Casino uses type: 1, Slot uses type: 2)
  return <Slot gameType={3} />;
}

export default Minigame;
