import { useState, useEffect, useRef } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/dialog";
import { Button } from "@/components/button";
import { Input } from "@/components/input";
import { useToast } from "@/hooks/use-toast";
import { apiService } from "@/services/api";
import { Loader2, Eye, EyeOff, X } from "lucide-react";
import { useTheme } from "@/hooks/useTheme";

interface ChangePasswordModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ChangePasswordModal = ({ isOpen, onClose }: ChangePasswordModalProps) => {
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [changingPassword, setChangingPassword] = useState(false);
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);
  const { toast } = useToast();
  const { themeConfig } = useTheme();
  
  // Refs for input fields
  const currentPasswordRef = useRef<HTMLInputElement>(null);
  const newPasswordRef = useRef<HTMLInputElement>(null);
  const confirmPasswordRef = useRef<HTMLInputElement>(null);

  // Reset form when modal closes
  useEffect(() => {
    if (!isOpen) {
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
      setShowCurrentPassword(false);
      setShowNewPassword(false);
      setShowConfirmPassword(false);
      setShowSuccessMessage(false);
    }
  }, [isOpen]);

  // Validation helpers
  const isPasswordLengthValid = newPassword.length === 0 || (newPassword.length >= 8 && newPassword.length <= 64);
  const isPasswordMatch = confirmPassword.length === 0 || newPassword === confirmPassword;
  const showPasswordLengthError = newPassword.length > 0 && !isPasswordLengthValid;
  const showPasswordMatchError = confirmPassword.length > 0 && !isPasswordMatch;

  const handleSubmitPasswordChange = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isPasswordLengthValid) {
      return;
    }

    if (!isPasswordMatch) {
      return;
    }

    try {
      setChangingPassword(true);
      const response = await apiService.changePassword({ password: newPassword });
      
      if (response.status === 'ok') {
        setShowSuccessMessage(true);
        // Close modal after 2 seconds
        setTimeout(() => {
          onClose();
        }, 2000);
      } else {
        toast({
          title: "Error",
          description: response.message || "Error al cambiar la contraseña",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al cambiar la contraseña",
        variant: "destructive",
      });
    } finally {
      setChangingPassword(false);
    }
  };

  return (
    <>
      <style>{`
        [data-password-modal] [data-radix-dialog-overlay] {
          z-index: 100 !important;
        }
        [data-password-modal] [data-radix-dialog-content] {
          z-index: 100 !important;
        }
      `}</style>
      <div data-password-modal>
        <Dialog open={isOpen} onOpenChange={() => {}}>
          <DialogContent 
            className="max-w-[80%] sm:max-w-[500px] bg-modal p-8 [&>button]:hidden z-[100]"
            style={{
              borderColor: themeConfig?.header.borderColor || '#27287e',
            }}
            onInteractOutside={(e) => {
              // Prevent closing when clicking outside
              e.preventDefault();
            }}
            onEscapeKeyDown={(e) => {
              // Prevent closing on escape key
              e.preventDefault();
            }}
          >
          {/* Header */}
          <div className="flex items-center justify-between mb-6">
            <DialogTitle className="text-lg sm:text-xl font-semibold text-modal-header">Cambiar Contraseña</DialogTitle>
            <DialogDescription className="sr-only">Formulario para cambiar la contraseña del usuario</DialogDescription>
            <button
              onClick={onClose}
              className="text-modal-header hover:text-[#0a8fff] transition-colors"
            >
              <X className="h-5 w-5 sm:h-6 sm:w-6" />
            </button>
          </div>

          {/* Form */}
          <form 
            onSubmit={handleSubmitPasswordChange} 
            className="space-y-4"
          >
            {/* Current Password */}
            <div>
              <label htmlFor="currentPassword" className="block text-modal-header text-sm mb-2 text-left font-medium">
                Contraseña Actual
              </label>
              <div className="relative">
                <Input
                  ref={currentPasswordRef}
                  id="currentPassword"
                  type={showCurrentPassword ? "text" : "password"}
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  className="text-white placeholder:text-[#B0B0B0] focus-visible:ring-0 pr-10 h-10 sm:h-12"
                  style={{
                    backgroundColor: themeConfig?.input.backgroundColor || '#1e1e1e',
                    borderColor: themeConfig?.input.borderColor || '#625b58',
                  }}
                  required
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowCurrentPassword(!showCurrentPassword);
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B0B0B0] hover:text-white transition-colors"
                >
                  {showCurrentPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            {/* New Password */}
            <div>
              <label htmlFor="newPassword" className="block text-modal-header text-sm mb-2 text-left font-medium">
                Nueva Contraseña
              </label>
              <div className="relative">
                <Input
                  ref={newPasswordRef}
                  id="newPassword"
                  type={showNewPassword ? "text" : "password"}
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="text-white placeholder:text-[#B0B0B0] focus-visible:ring-0 pr-10 h-10 sm:h-12"
                  style={{
                    backgroundColor: themeConfig?.input.backgroundColor || '#1e1e1e',
                    borderColor: themeConfig?.input.borderColor || '#625b58',
                  }}
                  required
                  minLength={8}
                  maxLength={64}
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowNewPassword(!showNewPassword);
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B0B0B0] hover:text-white transition-colors"
                >
                  {showNewPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              {showPasswordLengthError && (
                <p className="text-red-500 text-sm mt-1">
                  La contraseña debe tener entre 8 y 64 caracteres.
                </p>
              )}
            </div>

            {/* Confirm Password */}
            <div>
              <label htmlFor="confirmPassword" className="block text-modal-header text-sm mb-2 text-left font-medium">
                Confirmar Contraseña
              </label>
              <div className="relative">
                <Input
                  ref={confirmPasswordRef}
                  id="confirmPassword"
                  type={showConfirmPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="text-white placeholder:text-[#B0B0B0] focus-visible:ring-0 pr-10 h-10 sm:h-12"
                  style={{
                    backgroundColor: themeConfig?.input.backgroundColor || '#1e1e1e',
                    borderColor: themeConfig?.input.borderColor || '#625b58',
                  }}
                  required
                  minLength={8}
                  maxLength={64}
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setShowConfirmPassword(!showConfirmPassword);
                  }}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B0B0B0] hover:text-white transition-colors"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              {showPasswordMatchError && (
                <p className="text-red-500 text-sm mt-1">
                  Las contraseñas no coinciden
                </p>
              )}
            </div>

            {/* Success Message */}
            {showSuccessMessage && (
              <div className="mt-4 p-3 rounded-lg bg-green-500/20 border border-green-500/50">
                <p className="text-green-500 text-sm font-medium">
                  Contraseña modificada con éxito !
                </p>
              </div>
            )}

            {/* Submit Button */}
            <Button
              type="submit"
              disabled={changingPassword || !isPasswordLengthValid || !isPasswordMatch}
              className="w-full hover:opacity-90 text-white mt-6 h-9 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
              style={{
                backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
              }}
            >
              {changingPassword ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                "Cambiar Contraseña"
              )}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
    </>
  );
};

export default ChangePasswordModal;

