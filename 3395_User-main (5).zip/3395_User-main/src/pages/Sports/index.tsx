import { useEffect, useState, useRef } from "react";
import { apiService } from "@/services/api";
import { useAuth } from "@/hooks/useAuth";
import { useLoginModal } from "@/hooks/useLoginModal";
import { useTheme } from "@/hooks/useTheme";
import { Loader2 } from "lucide-react";

function Sports() {
    const [iframeUrl, setIframeUrl] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const { user, loading: authLoading } = useAuth();
    const { openLoginModal } = useLoginModal();
    const hasFetchedRef = useRef(false);
    const { themeConfig } = useTheme();

    useEffect(() => {
        if (authLoading) {
            return;
        }

        if (!user) {
            openLoginModal(undefined, undefined, "/sports");
            hasFetchedRef.current = false;
            return;
        }

        if (hasFetchedRef.current) {
            return;
        }

        const fetchSportsUrl = async () => {
            try {
                hasFetchedRef.current = true;
                setLoading(true);
                setError(null);
                const response = await apiService.enterSports();

                if (response.code === 0 && response.data?.gameUrl) {
                    setIframeUrl(response.data.gameUrl);
                } else {
                    setError(response.message || "No se pudo cargar deportes.");
                }
            } catch (err: unknown) {
                const message = err instanceof Error ? err.message : "No se pudo cargar deportes.";
                setError(message);
            } finally {
                setLoading(false);
            }
        };

        fetchSportsUrl();
    }, [authLoading, user, openLoginModal]);

    if (authLoading) {
        return (
            <div
                className="flex items-center justify-center min-h-[60vh]"
                style={{ color: themeConfig?.header?.textColor || "#ffffff" }}
            >
                <Loader2 className="w-8 h-8 animate-spin" />
            </div>
        );
    }

    if (!user) {
        return (
            <div
                className="flex items-center justify-center min-h-[60vh] p-4"
                style={{ color: themeConfig?.header?.textColor || "#ffffff" }}
            >
                <p className="text-lg">Inicia sesión para acceder a Deportes.</p>
            </div>
        );
    }

    if (loading) {
        return (
            <div
                className="flex items-center justify-center min-h-[60vh]"
                style={{ color: themeConfig?.header?.textColor || "#ffffff" }}
            >
                <Loader2 className="w-8 h-8 animate-spin" />
            </div>
        );
    }

    if (error) {
        return (
            <div
                className="flex flex-col items-center justify-center min-h-[60vh] p-4"
                style={{ color: themeConfig?.header?.textColor || "#ffffff" }}
            >
                <p className="text-red-400 text-lg mb-4">{error}</p>
                <button
                    onClick={() => window.location.reload()}
                    className="px-4 py-2 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-lg hover:brightness-110"
                    style={{
                        backgroundImage: "linear-gradient(to right, var(--gradient-from), var(--gradient-to))",
                        color: themeConfig?.header?.selectedTextColor || "#ffffff",
                    }}
                >
                    Reintentar
                </button>
            </div>
        );
    }

    if (!iframeUrl) {
        return (
            <div
                className="flex items-center justify-center min-h-[60vh] p-4"
                style={{ color: themeConfig?.header?.textColor || "#ffffff" }}
            >
                <p className="text-lg">No se pudo cargar deportes.</p>
            </div>
        );
    }

    return (
        <div className="w-full h-[calc(100vh-3.5rem-5rem)] sm:h-[calc(100vh-4rem-5rem)] md:h-[calc(100vh-4rem)] min-h-0 sports-iframe-height">
            <iframe
                src={iframeUrl}
                className="w-full h-full border-0"
                title="Deportes"
                allow="fullscreen"
                allowFullScreen
            />
        </div>
    );
}

export default Sports;
