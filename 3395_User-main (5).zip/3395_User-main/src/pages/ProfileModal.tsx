import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogTitle, DialogDescription } from "@/components/dialog";
import { Button } from "@/components/button";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { apiService } from "@/services/api";
import { Loader2, Plus, Minus, X } from "lucide-react";
import ChangePasswordModal from "@/pages/ChangePasswordModal";
import { useTheme } from "@/hooks/useTheme";

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
}

type TabType = "games" | "transacciones";

export const GameLogStatus = {
  PENDING: 0,
  WIN: 1,
  LOSE: 2,
  CANCELED: 4,
} as const;

export const UserCashLogType = {
  BET: 11,
  WIN: 12,
  DEPOSIT: 21,
  WITHDRAWAL: 22,
} as const;

interface Transaction {
  id: string;
  type: number;
  amount: string;
  fromBalance: string;
  toBalance: string;
  date: string;
  time: string;
}

interface Game {
  id: string;
  gameName: string;
  provider: string;
  bet: string;
  win: string;
  status: number;
  date: string;
  time: string;
}

const ProfileModal = ({ isOpen, onClose }: ProfileModalProps) => {
  const [activeTab, setActiveTab] = useState<TabType>("games");
  const [loadingBalance, setLoadingBalance] = useState(false);
  const [loadingGames, setLoadingGames] = useState(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [games, setGames] = useState<Game[]>([]);
  const [isChangePasswordOpen, setIsChangePasswordOpen] = useState(false);
  const { user, signOut } = useAuth();
  const { toast } = useToast();
  const { themeConfig } = useTheme();

  const tabs: TabType[] = ["games", "transacciones"];

  const handlePrevTab = () => {
    const currentIndex = tabs.indexOf(activeTab);
    const prevIndex = currentIndex === 0 ? tabs.length - 1 : currentIndex - 1;
    setActiveTab(tabs[prevIndex]);
  };

  const handleNextTab = () => {
    const currentIndex = tabs.indexOf(activeTab);
    const nextIndex = currentIndex === tabs.length - 1 ? 0 : currentIndex + 1;
    setActiveTab(tabs[nextIndex]);
  };



  // Fetch transactions from API
  useEffect(() => {
    const fetchTransactions = async () => {
      if (!user || !isOpen) return;
      
      try {
        setLoadingBalance(true);
        
        // Calculate date range (last 30 days)
        const now = new Date();
        const toDate = new Date(now);
        const fromDate = new Date(now);
        fromDate.setDate(fromDate.getDate() - 30);
        
        // Format dates to match API format: "YYYY-MM-DDTHH:mm:ss"
        const formatDate = (date: Date): string => {
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0');
          const day = String(date.getDate()).padStart(2, '0');
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');
          const seconds = String(date.getSeconds()).padStart(2, '0');
          return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
        };
        
        const toDateStr = formatDate(toDate);
        const fromDateStr = formatDate(fromDate);
        
        const response = await apiService.getTransactionHistory({
          fromDate: fromDateStr,
          toDate: toDateStr,
          type: -1,
          page: 1,
          limit: 20
        });
        
        if (response.status === 'ok' && response.data && response.data.data) {
          // Map API response to Transaction interface
          const mappedTransactions: Transaction[] = response.data.data.map((item: any) => {
            // Parse date from createdAt or created_at
            const dateStr = item.createdAt || item.created_at || item.date || new Date().toISOString();
            const transactionDate = new Date(dateStr);
            const month = String(transactionDate.getMonth() + 1).padStart(2, '0');
            const day = String(transactionDate.getDate()).padStart(2, '0');
            const hours = String(transactionDate.getHours()).padStart(2, '0');
            const minutes = String(transactionDate.getMinutes()).padStart(2, '0');
            
            // Get transaction details
            const type = item.type !== undefined ? item.type : UserCashLogType.DEPOSIT;
            const amount = item.amount || "0.00";
            const amountNum = typeof amount === 'string' ? parseFloat(amount) : amount;
            const toBalance = item.after || "0.00";
            const toBalanceNum = typeof toBalance === 'string' ? parseFloat(toBalance) : toBalance;
            
            // Calculate fromBalance based on transaction type
            let fromBalanceNum: number;
            if (type === UserCashLogType.BET || type === UserCashLogType.DEPOSIT) {
              // If BET or DEPOSIT: fromBalance = toBalance + amount (previous balance was higher)
              fromBalanceNum = toBalanceNum + amountNum;
            } else if (type === UserCashLogType.WIN || type === UserCashLogType.WITHDRAWAL) {
              // If WIN or WITHDRAWAL: fromBalance = toBalance - amount (previous balance was lower)
              fromBalanceNum = toBalanceNum - amountNum;
            } else {
              // For other types, use the item value or calculate
              const fromBalance = item.before || item.fromBalance || item.from_balance || "0.00";
              fromBalanceNum = typeof fromBalance === 'string' ? parseFloat(fromBalance) : fromBalance;
            }
            
            return {
              id: item._id || item.id || `#${Math.random().toString(36).substr(2, 9)}`,
              type: type,
              amount: amountNum.toFixed(2),
              fromBalance: fromBalanceNum.toFixed(2),
              toBalance: toBalanceNum.toFixed(2),
              date: `${month}/${day}`,
              time: `${hours}:${minutes}`,
            };
          });
          
          setTransactions(mappedTransactions);
        } else {
          setTransactions([]);
        }
      } catch (error: any) {
        console.error('Error fetching transactions:', error);
        setTransactions([]);
      } finally {
        setLoadingBalance(false);
      }
    };

    if (isOpen && activeTab === "transacciones") {
      fetchTransactions();
    }
  }, [isOpen, user, activeTab]);

  // Fetch games history from API
  useEffect(() => {
    const fetchGames = async () => {
      if (!user || !isOpen) return;
      
      try {
        setLoadingGames(true);
        
        // Calculate date range (last 30 days)
        const now = new Date();
        const toDate = new Date(now);
        const fromDate = new Date(now);
        fromDate.setDate(fromDate.getDate() - 30);
        
        // Format dates to match API format: "YYYY-MM-DDTHH:mm:ss"
        const formatDate = (date: Date): string => {
          const year = date.getFullYear();
          const month = String(date.getMonth() + 1).padStart(2, '0');
          const day = String(date.getDate()).padStart(2, '0');
          const hours = String(date.getHours()).padStart(2, '0');
          const minutes = String(date.getMinutes()).padStart(2, '0');
          const seconds = String(date.getSeconds()).padStart(2, '0');
          return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
        };
        
        const toDateStr = formatDate(toDate);
        const fromDateStr = formatDate(fromDate);
        
        const response = await apiService.getGameHistory({
          search: "",
          fromDate: fromDateStr,
          toDate: toDateStr,
          status: -1,
          page: 1,
          limit: 20
        });
        
        if (response.status === 'ok' && response.data && response.data.data) {
          // Map API response to Game interface
          const mappedGames: Game[] = response.data.data.map((item: any) => {
            // Parse date from createdAt or created_at
            const dateStr = item.createdAt || item.created_at || item.date || new Date().toISOString();
            const gameDate = new Date(dateStr);
            const month = String(gameDate.getMonth() + 1).padStart(2, '0');
            const day = String(gameDate.getDate()).padStart(2, '0');
            const hours = String(gameDate.getHours()).padStart(2, '0');
            const minutes = String(gameDate.getMinutes()).padStart(2, '0');
            
            // Calculate bet and win amounts
            const bet = item.bet_amount || "0.00";
            const win = item.win_amount || "0.00";
            const betNum = typeof bet === 'string' ? parseFloat(bet) : bet;
            const winNum = typeof win === 'string' ? parseFloat(win) : win;
            
            // Get status from API response, default to PENDING if not provided
            const status = item.status !== undefined ? item.status : GameLogStatus.PENDING;
            
            return {
              id: item._id || item.id || `#${Math.random().toString(36).substr(2, 9)}`,
              gameName: item.gameName || item.game_name || "Juego Desconocido",
              provider: item.game_provider_name || item.game_provider_id || "Proveedor Desconocido",
              bet: betNum.toFixed(2),
              win: winNum.toFixed(2),
              status: status,
              date: `${month}/${day}`,
              time: `${hours}:${minutes}`,
            };
          });
          
          setGames(mappedGames);
        } else {
          setGames([]);
        }
      } catch (error: any) {
        console.error('Error fetching games:', error);
        setGames([]);
      } finally {
        setLoadingGames(false);
      }
    };

    if (isOpen && activeTab === "games") {
      fetchGames();
    }
  }, [isOpen, user, activeTab]);

  const handleChangePassword = () => {
    setIsChangePasswordOpen(true);
  };

  const handleCloseChangePassword = () => {
    setIsChangePasswordOpen(false);
  };

  const handleSignOut = async () => {
    try {
      await signOut();
      toast({
        title: "Sesión cerrada",
        description: "Has cerrado sesión correctamente.",
      });
      onClose();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Error al cerrar sesión",
        variant: "destructive",
      });
    }
  };

  if (!user) {
    return null;
  }

  const displayName = user.firstName || "Usuario";
  const displayUsername = user.loginId || "";

  return (
    <>
      <style>{`
        @keyframes slideUp {
          from {
            transform: translate(-50%, -30%);
            opacity: 0;
          }
          to {
            transform: translate(-50%, -50%);
            opacity: 1;
          }
        }
        @keyframes slideDown {
          from {
            transform: translate(-50%, -50%);
            opacity: 1;
          }
          to {
            transform: translate(-50%, 100%);
            opacity: 0;
          }
        }
        .profile-modal-content[data-state="open"] {
          animation: slideUp 0.3s ease-out forwards;
        }
        .profile-modal-content[data-state="closed"] {
          animation: slideDown 0.3s ease-in forwards;
        }
      `}</style>
      <Dialog open={isOpen} onOpenChange={() => {}}>
        <DialogContent 
          className="profile-modal-content max-w-[90%] lg:max-w-[900px] h-[90%] bg-modal border-border overflow-hidden p-0 shadow-none [&>button]:hidden"
          onInteractOutside={(e) => {
            // Prevent closing when clicking outside, but allow if clicking on password modal
            const target = e.target as HTMLElement;
            if (target.closest('[data-password-modal]') || target.closest('[data-radix-dialog-content]')) {
              return;
            }
            e.preventDefault();
          }}
          onEscapeKeyDown={(e) => {
            // Prevent closing on escape key
            e.preventDefault();
          }}
        >
        <div className="relative w-full h-full flex flex-col">
          {/* Header */}
          <div className="flex items-center justify-between px-4 py-2">
            <DialogTitle className="text-xl sm:text-2xl font-semibold text-modal-header">Cuenta</DialogTitle>
            <DialogDescription className="sr-only">Perfil de usuario y configuración de cuenta</DialogDescription>
            <button
              onClick={() => {
                if (isChangePasswordOpen) {
                  return;
                }
                onClose();
              }}
              className="text-modal-header hover:text-[#0a8fff] transition-colors"
            >
              <X className="h-5 w-5 sm:h-6 sm:w-6" />
            </button>
          </div>

          {/* User Details Section */}
          <div className="px-4 py-2">
            <div className="flex justify-between gap-2 mb-2 sm:gap-4 sm:mb-4">
              <div>
                <p className="text-[#E0E0E0] text-sm md:text-lg font-medium mb-1">Nombre:</p>
                <p className="text-[#E0E0E0] text-sm md:text-lg font-medium ">{displayName}</p>
              </div>
              <div>
                <p className="text-[#E0E0E0] text-sm md:text-lg font-medium  mb-1">Usuario:</p>
                <p className="text-[#E0E0E0] text-sm md:text-lg font-medium">{displayUsername}</p>
              </div>
              
              <Button
                className="text-white px-1.5 sm:px-3 py-0.5 sm:py-1 text-sm h-5 sm:h-7 hover:opacity-90"
                style={{
                  backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.filter = 'brightness(1.1)';
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.filter = 'brightness(1)';
                }}
              >
                <span className="text-xs">ES</span> <span className="hidden sm:inline">Español</span>
              </Button>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col gap-2 mt-3 sm:gap-3 sm:mt-6">
              <Button
                onClick={handleChangePassword}
                className="border px-3 py-1 h-[30px] text-sm hover:text-white"
                style={{
                  backgroundColor: themeConfig?.modal.buttonColor || '#030f2f',
                  borderColor: themeConfig?.colors.border || '#27287e',
                  color: themeConfig?.modal.headerColor || '#5b9eeb',
                }}
              >
                Cambiar Contraseña
              </Button>
              <Button
                onClick={handleSignOut}
                className="border px-3 py-1 h-[30px] text-sm hover:text-white"
                style={{
                  backgroundColor: themeConfig?.modal.buttonColor || '#030f2f',
                  borderColor: themeConfig?.colors.border || '#27287e',
                  color: themeConfig?.modal.headerColor || '#5b9eeb',
                }}
              >
                Cerrar Sesión
              </Button>
            </div>
          </div>

          {/* Tabs */}
          <div 
            className="flex border-none mx-2 mt-3 mb-1 sm:mx-4 sm:mt-6 sm:mb-2"
            style={{
              borderColor: themeConfig?.header.borderColor || '#27287e',
            }}
          >
            <button
              onClick={() => setActiveTab("games")}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                activeTab === "games"
                  ? "text-modal-header border-b-2"
                  : "text-[#E0E0E0] hover:text-white"
              }`}
              style={activeTab === "games" ? {
                borderColor: themeConfig?.modal.headerColor || '#eb5b5b',
              } : {}}
            >
              Games
            </button>
            <button
              onClick={() => setActiveTab("transacciones")}
              className={`px-4 py-2 text-sm font-medium transition-colors ${
                activeTab === "transacciones"
                  ? "text-modal-header border-b-2"
                  : "text-[#E0E0E0] hover:text-white"
              }`}
              style={activeTab === "transacciones" ? {
                borderColor: themeConfig?.modal.headerColor || '#eb5b5b',
              } : {}}
            >
              Transacciones
            </button>
          </div>

          {/* Tab Content */}
          <div className="px-4 py-4 sm:py-6 flex-grow w-full mb-10">
            <div className="max-h-[80%] overflow-y-auto custom-scrollbar">              {activeTab === "games" && (
                <div>
                  <h3 className="text-sm sm:text-xl font-semibold text-modal-header mb-2 sm:mb-4">Game Recientes</h3>

                  {/* Games List */}
                  {loadingGames ? (
                    <div className="flex justify-center py-4 sm:py-8">
                      <Loader2 className="w-4 h-4 sm:w-6 sm:h-6 animate-spin text-modal-header" />
                    </div>
                  ) : games.length > 0 ? (
                    <div className="space-y-2 sm:space-y-3">
                      {games.map((game) => (
                        <div
                          key={game.id}
                          className="relative border p-2 sm:p-3 rounded-lg"
                          style={{
                            backgroundColor: themeConfig?.modal.buttonColor || '#000719',
                            borderColor: themeConfig?.header.borderColor || '#27287e',
                          }}
                        >
                          {/* Status Tag - Top Left */}
                          <div className={`absolute top-1.5 left-1.5 sm:top-3 sm:left-3 px-1.5 sm:px-3 py-0.5 sm:py-1 rounded text-white text-[10px] sm:text-xs font-medium ${
                            game.status === GameLogStatus.WIN ? "bg-green-500" :
                            game.status === GameLogStatus.LOSE ? "bg-red-500" :
                            game.status === GameLogStatus.CANCELED ? "bg-gray-500" :
                            "bg-yellow-500"
                          }`}>
                            {game.status === GameLogStatus.WIN ? "Ganado" :
                            game.status === GameLogStatus.LOSE ? "Perdido" :
                            game.status === GameLogStatus.CANCELED ? "Cancelado" :
                            "Pendiente"}
                          </div>

                          {/* Game Details */}
                          <div className="mt-6 sm:mt-8">
                            {/* Game Name and ID */}
                            <div className="flex items-center justify-between">
                              <p className="text-modal-header font-medium mb-0.5 sm:mb-1 text-xs sm:text-lg">{game.gameName}</p>
                              <p className="text-modal-header text-[10px] sm:text-sm max-w-1/3 break-words text-right">#{game.id}</p>
                            </div>
                            
                            <p className="text-[#E0E0E0] text-[10px] sm:text-sm mb-0.5 sm:mb-1">Proveedores: {game.provider}</p>
                            <div className="flex items-center gap-2 sm:gap-4">
                              <p className="text-green-500 font-medium text-[10px] sm:text-sm">Ganancia: ${game.win}</p>
                              <p className="text-red-500 font-medium text-[10px] sm:text-sm">Apuesta: ${game.bet}</p>
                            </div>
                            <p className="text-white text-[10px] sm:text-sm mt-0.5 sm:mt-1">
                              {game.date}, {game.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[#E0E0E0] text-center py-4 sm:py-8 text-[10px] sm:text-base">No hay game disponibles.</p>
                  )}
                </div>
              )}

              {activeTab === "transacciones" && (
                <div>
                  <h3 className="text-sm sm:text-xl font-semibold text-modal-header mb-2 sm:mb-4">Transacciones Recientes</h3>

                  {/* Transactions List */}
                  {loadingBalance ? (
                    <div className="flex justify-center py-4 sm:py-8">
                      <Loader2 className="w-4 h-4 sm:w-6 sm:h-6 animate-spin text-modal-header" />
                    </div>
                  ) : transactions.length > 0 ? (
                    <div className="space-y-2 sm:space-y-3">
                      {transactions.map((transaction) => (
                        <div
                          key={transaction.id}
                          className="flex items-center border gap-1.5 sm:gap-4 p-2 sm:p-4 rounded-lg"
                          style={{
                            backgroundColor: themeConfig?.modal.buttonColor || '#000719',
                            borderColor: themeConfig?.header.borderColor || '#27287e',
                          }}
                        >
                          {/* Circle Icon */}
                          <div className={`flex-shrink-0 w-6 h-6 sm:w-10 sm:h-10 rounded-full flex items-center justify-center ${
                            transaction.type === UserCashLogType.BET || transaction.type === UserCashLogType.DEPOSIT ? 'bg-red-500' : 'bg-green-500'
                          }`}>
                            {transaction.type === UserCashLogType.BET || transaction.type === UserCashLogType.DEPOSIT ? (
                              <Minus className="w-3 h-3 sm:w-5 sm:h-5 text-white" />
                            ) : (
                              <Plus className="w-3 h-3 sm:w-5 sm:h-5 text-white" />
                            )}
                          </div>

                          {/* Transaction Details */}
                          <div className="flex-1 min-w-0">
                            {/* Transaction ID */}
                          <div className="flex items-center justify-between">
                            <p className="text-modal-header font-medium mb-0.5 sm:mb-1 text-xs sm:text-lg">
                              {transaction.type === UserCashLogType.BET ? "Apuesta" :
                              transaction.type === UserCashLogType.WIN ? "Ganancia" :
                              transaction.type === UserCashLogType.DEPOSIT ? "Depósito" :
                              transaction.type === UserCashLogType.WITHDRAWAL ? "Retiro" :
                              "Transacción"}
                            </p>
                            <p className="text-modal-header text-[10px] sm:text-sm w-1/3 break-words text-right">#{transaction.id}</p>
                          </div>
                            
                            <p className="text-white font-medium text-[10px] sm:text-sm mb-0.5 sm:mb-1">Monto: ${transaction.amount}</p>
                            <p className="text-modal-header text-xs sm:text-lg font-medium">
                              ${transaction.fromBalance} {'>'} {transaction.toBalance}
                            </p>
                            <p className="text-white text-[10px] sm:text-sm mt-0.5 sm:mt-1">
                              {transaction.date}, {transaction.time}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-[#E0E0E0] text-center py-4 sm:py-8 text-[10px] sm:text-base">No hay transacciones disponibles.</p>
                  )}
                </div>
              )}
            </div> 
          </div>
          

          {/* Tab Navigation */}
          <div className="fixed flex items-center justify-between p-2 sm:p-4 bottom-0 left-0 right-0 z-10 bg-modal">
            <Button
              onClick={handlePrevTab}
              className="inactive text-[#E0E0E0] text-[10px] sm:text-sm px-2 sm:px-4 py-1 sm:py-2 hover:opacity-90"
              style={{
                backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
              }}
            >
              Prev
            </Button>
            <Button
              onClick={handleNextTab}
              className="inactive text-[#E0E0E0] text-[10px] sm:text-sm px-2 sm:px-4 py-1 sm:py-2 hover:opacity-90"
              style={{
                backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
              }}
            >
              Next
            </Button>
          </div>
        </div>
      </DialogContent>

      {/* Change Password Modal */}
      <ChangePasswordModal 
        isOpen={isChangePasswordOpen} 
        onClose={handleCloseChangePassword} 
      />
      </Dialog>
    </>
  );
};

export default ProfileModal;
