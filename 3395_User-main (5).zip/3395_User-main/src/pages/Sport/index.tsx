import Slot from "../Slot";

function Sport() {
  // Sport uses type: 5 (Casino: 1, Slot: 2, Minigame: 3)
  return <Slot gameType={5} />;
}

export default Sport;
