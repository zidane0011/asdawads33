import { useEffect, useState, useRef } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { Loader2, ArrowLeft, Maximize, Minimize } from "lucide-react";
import { apiService } from "@/services/api";
import { useAuth } from "@/hooks/useAuth";
import { useLoginModal } from "@/hooks/useLoginModal";
import LoginModal from "@/pages/LoginModal";
import { useTheme } from "@/hooks/useTheme";

const GameDetail = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const { accessToken, user } = useAuth();
  const { isLoginOpen, openLoginModal, closeLoginModal } = useLoginModal();
  const { themeConfig } = useTheme();
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [gameUrl, setGameUrl] = useState<string | null>(null);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const hasFetchedRef = useRef(false);
  const gameContainerRef = useRef<HTMLDivElement>(null);

  const gameCode = searchParams.get("game_code");
  const vendorCode = searchParams.get("vendor_code");
  const gameKeyRef = useRef<string>("");

  useEffect(() => {
    // Check if user is authenticated
    if (!accessToken && !user) {
      openLoginModal();
      setLoading(false);
      return;
    }

    // Close login modal if user is now authenticated
    if (isLoginOpen && (accessToken || user)) {
      closeLoginModal();
      // Reset fetch ref to allow game to load after login
      hasFetchedRef.current = false;
    }

    const currentKey = `${gameCode}-${vendorCode}`;
    
    // Skip if already fetched for this game
    if (hasFetchedRef.current && gameKeyRef.current === currentKey) {
      return;
    }

    // Reset if game changed
    if (gameKeyRef.current !== currentKey) {
      hasFetchedRef.current = false;
      setGameUrl(null);
      setError(null);
      setLoading(true);
      gameKeyRef.current = currentKey;
    }

    const enterGame = async () => {
      if (!gameCode || !vendorCode) {
        setError("Falta el código del juego o del proveedor");
        setLoading(false);
        return;
      }

      hasFetchedRef.current = true;

      try {
        setLoading(true);
        setError(null);

        console.log('[Game] 🎮 Entering game - game_code:', gameCode, 'vendor_code:', vendorCode);
        console.log('[Game] 💰 Current balance before entering game:', user?.balance);

        const response = await apiService.enterGame({
          game_code: gameCode,
          vendor_code: vendorCode,
        });

        console.log('[Game] 📡 Enter game API response:', response);

        if (response.status === "ok" && response.data?.game_url) {
          setGameUrl(response.data.game_url);
          console.log('[Game] ✅ Game URL received:', response.data.game_url);
          console.log('[Game] 💰 Balance after entering game (should decrease):', user?.balance);
          // Optionally redirect to the game URL
          // window.location.href = response.data.game_url;
        } else {
          console.error('[Game] ❌ Failed to enter game:', response.message);
          setError(response.message || "Error al cargar el juego");
        }
      } catch (err: any) {
        console.error('[Game] ❌ Error entering game:', err);
        const errorMessage = err.message || "Error al cargar el juego";
        setError(errorMessage);
      } finally {
        setLoading(false);
      }
    };

    enterGame();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [gameCode, vendorCode, accessToken, user, isLoginOpen]);

  const handleLoginClose = () => {
    closeLoginModal();
    // Navigate back after closing login modal if not authenticated
    if (!accessToken && !user) {
      navigate(-1);
    }
  };

  const handleBack = () => {
    navigate(-1);
  };

  const toggleFullscreen = async () => {
    if (!gameContainerRef.current) return;

    try {
      if (!document.fullscreenElement) {
        await gameContainerRef.current.requestFullscreen();
        setIsFullscreen(true);
      } else {
        await document.exitFullscreen();
        setIsFullscreen(false);
      }
    } catch (err) {
      console.error('Error toggling fullscreen:', err);
    }
  };

  useEffect(() => {
    const handleFullscreenChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };

    document.addEventListener('fullscreenchange', handleFullscreenChange);
    return () => {
      document.removeEventListener('fullscreenchange', handleFullscreenChange);
    };
  }, []);

  // Show login modal if not authenticated
  if (isLoginOpen) {
    return <LoginModal isOpen={isLoginOpen} onClose={handleLoginClose} />;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-theme-primary flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <Loader2 
            className="w-8 h-8 animate-spin" 
            style={{ color: themeConfig?.gradient.to || '#ca8005' }}
          />
          {/* <p className="text-[#E0E0E0]">Cargando juego...</p> */}
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-theme-primary flex items-center justify-center px-4">
        <div className="flex flex-col items-center gap-4 max-w-md text-center">
          <p className="text-red-400 text-lg">{error}</p>
          <button
            onClick={handleBack}
            className="px-6 py-3 rounded-full text-white font-medium transition-all duration-200 shadow-md hover:shadow-lg flex items-center gap-2"
            style={{
              backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.filter = 'brightness(1.1)';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.filter = 'brightness(1)';
            }}
          >
            <ArrowLeft className="w-5 h-5" />
            Volver
          </button>
        </div>
      </div>
    );
  }

  if (gameUrl) {
    return (
      <div ref={gameContainerRef} className="min-h-screen bg-theme-primary">
        <div className="sticky z-10 bg-theme-primary px-4 py-3 flex items-center justify-between">
          {!isFullscreen && (
            <button
              onClick={handleBack}
              className="flex items-center gap-2 text-[#E0E0E0] hover:text-white transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              <span>Atrás</span>
            </button>
          )}
          <button
            onClick={toggleFullscreen}
            className={`flex items-center gap-2 text-[#E0E0E0] hover:text-white transition-colors ${isFullscreen ? 'ml-auto' : ''}`}
            aria-label={isFullscreen ? "Salir de pantalla completa" : "Pantalla completa"}
          >
            {isFullscreen ? (
              <>
                <Minimize className="w-5 h-5" />
                <span>Salir</span>
              </>
            ) : (
              <>
                <Maximize className="w-5 h-5" />
                <span>Pantalla completa</span>
              </>
            )}
          </button>
        </div>
        <iframe
          src={gameUrl}
          className="w-full h-[calc(100vh-5rem)] lg:h-[calc(100vh-1rem)] border-0"
          title="Juego"
          allow="fullscreen"
        />
      </div>
    );
  }

  return null;
};

export default GameDetail;

