import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogTitle } from "@/components/dialog";
import { Button } from "@/components/button";
import { Input } from "@/components/input";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { useLoginModal } from "@/hooks/useLoginModal";
import { useTheme } from "@/hooks/useTheme";

interface LoginModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const LoginModal = ({ isOpen, onClose }: LoginModalProps) => {
  const [isSignUp, setIsSignUp] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [loginId, setLoginId] = useState("");
  const [password, setPassword] = useState("");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(false);
  const [loginIdError, setLoginIdError] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const { signIn, signUp } = useAuth();
  const { toast } = useToast();
  const { pendingGame, pendingRedirectPath, clearPendingGame } = useLoginModal();
  const { themeConfig } = useTheme();
  const navigate = useNavigate();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      if (isSignUp) {
        const { error } = await signUp(loginId, password, username);
        if (error) {
          toast({
            title: "Error",
            description: error.message,
            variant: "destructive",
          });
        } else {
          toast({
            title: "¡Éxito!",
            description: "Tu cuenta ha sido creada. Ya estás conectado.",
          });
          onClose();
          resetForm();
          
          if (pendingGame) {
            navigate(`/game?game_code=${encodeURIComponent(pendingGame.gameCode)}&vendor_code=${encodeURIComponent(pendingGame.vendorCode)}`);
            clearPendingGame();
          } else if (pendingRedirectPath) {
            navigate(pendingRedirectPath);
          }
        }
      } else {
        // Clear previous errors
        setLoginIdError("");
        setPasswordError("");
        
        const { error } = await signIn(loginId, password);
        if (error) {
          // Check for specific error messages and show them below the respective fields
          if (error.message === "Login ID is unregistered.") {
            setLoginIdError("El ID de inicio de sesión no está registrado.");
          } else if (error.message === "Password is incorrect.") {
            setPasswordError("La contraseña es incorrecta.");
          } else {
            // For other errors, show toast
            toast({
              title: "Error",
              description: error.message,
              variant: "destructive",
            });
          }
        } else {
          toast({
            title: "¡Bienvenido de nuevo!",
            description: "Has iniciado sesión correctamente.",
          });
          onClose();
          resetForm();
          
          if (pendingGame) {
            navigate(`/game?game_code=${encodeURIComponent(pendingGame.gameCode)}&vendor_code=${encodeURIComponent(pendingGame.vendorCode)}`);
            clearPendingGame();
          } else if (pendingRedirectPath) {
            navigate(pendingRedirectPath);
          }
        }
      }
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Ocurrió un error inesperado",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const resetForm = () => {
    setLoginId("");
    setPassword("");
    setUsername("");
    setIsSignUp(false);
    setLoginIdError("");
    setPasswordError("");
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-[90%] sm:max-w-[600px] min-h-[500px] bg-modal border-border overflow-hidden py-24">
        <DialogTitle className="sr-only">
          {isSignUp ? "Crear cuenta" : "Iniciar sesión"}
        </DialogTitle>
        <div className="relative sm:p-6">

          {/* Logo */}
          <div className="flex justify-center mb-6">
            <img 
              src={themeConfig?.logo.image || '/logo.png'} 
              alt="Bet30 Logo" 
              className="h-8 sm:h-16 md:h-24" 
            />
          </div>

          {/* Subtitle */}
          <p className="text-center text-[#E0E0E0] mb-12">
            {isSignUp
              ? "Crea tu cuenta para empezar a jugar"
              : "Ingrese su usuario y contraseña para empezar a jugar"}
          </p>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-8">
            {isSignUp && (
              <div>
                <Input
                  id="username"
                  type="text"
                  placeholder="Usuario"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-[#212c36] border-[#4b5563] text-white placeholder:text-[#E0E0E0] focus-visible:ring-0 h-10 sm:h-12"
                  required
                />
              </div>
            )}

            <div>
                <Input
                  id="loginId"
                  type="text"
                  placeholder="Usuario"
                  value={loginId}
                  onChange={(e) => {
                    setLoginId(e.target.value);
                    // Clear error when user starts typing
                    if (loginIdError) {
                      setLoginIdError("");
                    }
                  }}
                  className="bg-[#212c36] border-[#4b5563] text-white placeholder:text-[#E0E0E0] focus-visible:ring-0 h-10 sm:h-12"
                  required
                />
            </div>

            <div className="relative">
              <Input
                id="password"
                type={showPassword ? "text" : "password"}
                placeholder="Contraseña"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  // Clear error when user starts typing
                  if (passwordError) {
                    setPasswordError("");
                  }
                }}
                className="bg-[#212c36] border-[#4b5563] text-white placeholder:text-[#B0B0B0] focus-visible:ring-0 pr-10 h-10 sm:h-12"
                required
                minLength={3}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-[#B0B0B0] hover:text-white transition-colors"
              >
                {showPassword ? (
                  <EyeOff className="w-5 h-5" />
                ) : (
                  <Eye className="w-5 h-5" />
                )}
              </button>
            </div>
            {loginIdError && (
              <p className="text-red-500 text-sm mt-1">
                {loginIdError}
              </p>
            )}
            {passwordError && (
              <p className="text-red-500 text-sm mt-1">
                {passwordError}
              </p>
            )}

            <Button
              type="submit"
              disabled={loading}
              className="w-full hover:opacity-90 text-lg py-6 text-white h-8 sm:h-12 md:h-10"
              style={{
                backgroundImage: `linear-gradient(to right, ${themeConfig?.gradient.from || '#940000'}, ${themeConfig?.gradient.to || '#ca8005'})`,
              }}
            >
              {loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : isSignUp ? (
                "Crear cuenta"
              ) : (
                "Entrar"
              )}
            </Button>
          </form>

          {/* Toggle Sign Up / Sign In */}
          {/* <div className="mt-6 text-center">
            <p className="text-[#E0E0E0]">
              {isSignUp ? "¿Ya tienes una cuenta?" : "¿No tienes una cuenta?"}
              <button
                onClick={() => setIsSignUp(!isSignUp)}
                className="ml-2 text-[hsl(var(--bet-blue))] hover:underline font-medium"
              >
                {isSignUp ? "Iniciar sesión" : "Registrarse"}
              </button>
            </p>
          </div> */}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default LoginModal;
