import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import { apiService, GameType, type Provider } from "@/services/api";
import { useDragScroll } from "@/hooks/useDragScroll";
import { useTheme } from "@/hooks/useTheme";


// Module-level cache to prevent duplicate API calls across Strict Mode remounts
let providersCache: { data: Provider[] | null; timestamp: number; gameType: number } | null = null;
const CACHE_DURATION = 5000; // 5 seconds cache

const Providers = () => {
  const navigate = useNavigate();
  const [providers, setProviders] = useState<Provider[]>([]);
  const [error, setError] = useState<string | null>(null);
  const gameType = 2; // Home page uses gameType 2
  const isMountedRef = useRef(true);
  const hasFetchedRef = useRef(false);
  const dragScrollRef = useDragScroll();
  const { themeConfig } = useTheme();
  const handleProviderClick = (provider: Provider) => {
    // Navigate to slot page with vendorCode and gameType
    // gameType 1 = casino, gameType 2 = slots
    if (provider.type === 1) {
      navigate(`/casino?vendor=${provider.vendorCode}`);
    } else {
      navigate(`/slots?vendor=${provider.vendorCode}`);
    }
  };

  useEffect(() => {
    isMountedRef.current = true;

    // Check cache first (prevents duplicate calls in Strict Mode)
    // Only use cache if it matches the current gameType
    if (
      providersCache && 
      Date.now() - providersCache.timestamp < CACHE_DURATION &&
      providersCache.gameType === gameType
    ) {
      if (providersCache.data) {
        setProviders(providersCache.data);
        hasFetchedRef.current = true;
        return;
      }
    }

    // Skip if already fetched in this render cycle
    if (hasFetchedRef.current) {
      return;
    }

    hasFetchedRef.current = true;

    const fetchProviders = async () => {
      try {
        setError(null);
        const response = await apiService.getProviders(gameType as GameType);
        
        // Only update state if component is still mounted
        if (!isMountedRef.current) return;
        
        if (response.status === 'ok' && response.data) {
          // Sort by sequence to maintain order
          const sortedProviders = [...response.data.providers].sort((a, b) => a.sequence - b.sequence);
          setProviders(sortedProviders);
          // Update cache with gameType
          providersCache = { data: sortedProviders, timestamp: Date.now(), gameType: gameType };
        } else {
          setError(response.message || 'Failed to load providers');
        }
      } catch (err: any) {
        // Don't update state if component unmounted
        if (!isMountedRef.current) return;
        
        setError(err.message || 'Failed to load providers');
        console.error('Error fetching providers:', err);
      } finally {
        hasFetchedRef.current = false;
      }
    };

    fetchProviders();

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return (
    <section className="w-full bg-theme-primary py-4">
      <div className="px-4">
        {/* Title Section */}
        <div className="flex items-center mb-3">
          <svg fill="white" viewBox="0 0 96 96" width="20" height="20"> 
            <path fillRule="evenodd" clipRule="evenodd" d="M48.117 24.078c6.648 0 12.04-5.391 12.04-12.039S54.764 0 48.116 0C41.47 0 36.078 5.391 36.078 12.039s5.391 12.039 12.04 12.039ZM3.594 50.246l40.003 18.4a10.33 10.33 0 0 0 4.32.933 10.41 10.41 0 0 0 4.387-.96l-.066.027 40.003-18.4a2.608 2.608 0 0 0 1.509-2.362 2.597 2.597 0 0 0-1.494-2.352l-.015-.006-39.445-18.16v16.36a4.8 4.8 0 0 1-4.8 4.8 4.8 4.8 0 0 1-4.801-4.8v-16.36L3.59 45.526a2.608 2.608 0 0 0-1.509 2.361c0 1.041.612 1.939 1.494 2.353l.015.006h.003Zm40.403 28.922L2.074 60.206V72.82c0 1.932 1.134 3.6 2.772 4.377l.03.012L44 95.13c1.173.55 2.55.87 4 .87 1.449 0 2.826-.32 4.059-.893l-.06.024 39.124-17.92c1.668-.79 2.799-2.458 2.799-4.39V60.206L51.999 79.168a9.305 9.305 0 0 1-4 .888 9.365 9.365 0 0 1-4-.889l.001-.002-.057-.024.055.026v.001Z"></path>
          </svg>
          <div className="px-2 py-1">
            <h2 
              className="text-lg sm:text-xl md:text-2xl font-semibold whitespace-nowrap"
              style={{ color: themeConfig?.header.selectedTextColor || '#ffffff' }}
            >
              Proveedores
            </h2>
          </div>
        </div>

        {/* Providers Grid - Horizontal Scrollable on desktop, Static grid on mobile */}
        <div ref={dragScrollRef} className="overflow-x-auto md:pb-2 md:custom-scrollbar scrollbar-hide-mobile">
          {error ? (
            <div className="text-center py-8">
              <p className="text-red-400 text-sm">{error}</p>
            </div>
          ) : providers.length === 0 ? null : (
            <div className="flex gap-2 min-w-max">
              {providers
                .filter(provider => provider.launch_enable)
                .map((provider) => (
                  <div
                    key={provider._id}
                    onClick={() => handleProviderClick(provider)}
                    className="flex-shrink-0 border rounded-full flex items-center justify-center gap-2 px-2 py-1.5 md:px-3 md:py-2 hover:border-[#3b82f6] transition-colors cursor-pointer"
                    style={{
                      backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                      borderColor: themeConfig?.header.borderColor || '#27287e',
                    }}
                  >
                    <img
                      src={provider.thumbnail}
                      alt={provider.name}
                      className="w-8 h-8 md:w-10 md:h-10 object-contain flex-shrink-0"
                      onError={(e) => {
                        // Fallback to a placeholder if image fails to load
                        (e.target as HTMLImageElement).src = '/logo.png';
                      }}
                    />
                    <span 
                      className="text-xs md:text-sm font-medium whitespace-nowrap block"
                      style={{ color: themeConfig?.header.textColor || '#ffffff' }}
                    >
                      {provider.name}
                    </span>
                  </div>
                ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

export default Providers;

