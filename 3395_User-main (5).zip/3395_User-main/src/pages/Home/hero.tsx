import { useTheme } from "@/hooks/useTheme";

const Hero = () => {
  const { themeConfig } = useTheme();

  return (
    <section 
      className="relative w-full h-auto md:h-[500px] overflow-hidden"
      style={{
        backgroundColor: themeConfig?.banner.backgroundColor || '#000719'
      }}
    >
      <video
        autoPlay
        loop
        muted
        playsInline
        className="w-full h-auto md:h-full object-cover"
      >
        <source src="https://assets.a7a.info/media/video-storage/bet30-new.mp4" type="video/mp4" />
        Your browser does not support the video tag.
      </video>
    </section>
  );
};

export default Hero;
