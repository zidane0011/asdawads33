import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import GameCard from "@/components/gamecard";
import { apiService, type Game } from "@/services/api";
import { useTheme } from "@/hooks/useTheme";

// Module-level cache to prevent duplicate API calls across Strict Mode remounts
let homeGamesCache: { data: Game[] | null; timestamp: number } | null = null;
const CACHE_DURATION = 5000; // 5 seconds cache

const TopGamesSection = () => {
  const navigate = useNavigate();
  const [games, setGames] = useState<Game[]>([]);
  const [error, setError] = useState<string | null>(null);
  const isMountedRef = useRef(true);
  const hasFetchedRef = useRef(false);
  const { themeConfig } = useTheme();

  useEffect(() => {
    isMountedRef.current = true;

    // Check cache first (prevents duplicate calls in Strict Mode)
    if (homeGamesCache && Date.now() - homeGamesCache.timestamp < CACHE_DURATION) {
      if (homeGamesCache.data) {
        setGames(homeGamesCache.data);
        hasFetchedRef.current = true;
        return;
      }
    }

    // Skip if already fetched in this render cycle
    if (hasFetchedRef.current) {
      return;
    }

    hasFetchedRef.current = true;

    const fetchGames = async () => {
      try {
        setError(null);
        const response = await apiService.getHomeGames(1);
        
        // Only update state if component is still mounted
        if (!isMountedRef.current) return;
        
        if (response.status === 'ok' && response.data) {
          // Filter only games with launch_enable and sort by sequence
          const enabledGames = response.data.data
            .filter(game => game.launch_enable)
            .sort((a, b) => a.sequence - b.sequence);
          setGames(enabledGames);
          // Update cache
          homeGamesCache = { data: enabledGames, timestamp: Date.now() };
        } else {
          setError(response.message || 'Failed to load games');
        }
      } catch (err: any) {
        // Don't update state if component unmounted
        if (!isMountedRef.current) return;
        
        setError(err.message || 'Failed to load games');
        console.error('Error fetching home games:', err);
      } finally {
        hasFetchedRef.current = false;
      }
    };

    fetchGames();

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return (
    <section className="py-6 px-4 bg-theme-primary">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="relative flex items-center gap-2">
          <div className="relative">
            <div className="relative w-auto h-8">
              <img src="https://assets.a7a.info/templates/bet30/images/providers/trending.png" alt="Trending" className="w-full h-full" />
            </div>
          </div>
          <h2 
            className="text-lg md:text-xl font-bold"
            style={{ color: themeConfig?.header.selectedTextColor || '#ffffff' }}
          >
            Top
          </h2>
        </div>

        <button 
          onClick={() => navigate('/slots?view=top')}
          className="px-4 py-2 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-lg hover:brightness-110"
          style={{
            backgroundImage: 'linear-gradient(to right, var(--gradient-from), var(--gradient-to))',
            color: themeConfig?.header.selectedTextColor || '#ffffff',
          }}
        >
          Ver más
        </button>
      </div>

      {/* Blue line below header */}
      <div className="h-[2px] mb-4 w-12" style={{ backgroundColor: 'var(--scrollbar-thumb)' }}></div>

      {/* Games Carousel */}
      <div className="relative">
        {error ? (
          <div className="text-center py-8">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        ) : games.length === 0 ? null : (
          <div className="grid grid-cols-3 gap-3 md:gap-4 md:grid-cols-6 2xl:grid-cols-8">
            {games.map((game, index) => {
              // Show first 6 games on all screens
              // Show games 7-8 (index 6-7) only on 2xl screens (>= 1280px)
              if (index < 6) {
                return (
                  <div key={game._id} className="block">
                    <GameCard title={game.gameName} imageUrl={game.thumbnail} gameCode={game.gameCode} vendorCode={game.vendorCode} />
                  </div>
                );
              } else if (index < 8) {
                // Games 7-8: visible only on 2xl screens
                return (
                  <div key={game._id} className="hidden 2xl:block">
                    <GameCard title={game.gameName} imageUrl={game.thumbnail} gameCode={game.gameCode} vendorCode={game.vendorCode} />
                  </div>
                );
              } else {
                // Games beyond 8: hidden
                return null;
              }
            })}
          </div>
        )}

        {/* Fade edges */}
        <div className="absolute right-0 top-0 bottom-4 w-16 bg-gradient-to-l from-background to-transparent pointer-events-none" />
      </div>
    </section>
  );
};

export default TopGamesSection;
