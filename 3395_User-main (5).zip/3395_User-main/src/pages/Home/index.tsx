import Hero from "./hero";
import Providers from "./providers";
import Top from "./top";
import Pragmatic from "./pragmatic";
import RubyPlay from "./rubyplay";
import KAGaming from "./kagaming";
import Casino from "./casino";

function Home() {

  return (
    <div className="flex flex-col">
      <Hero />
      <Providers />
      <Top />
      <Pragmatic />
      <RubyPlay />
      <KAGaming />
      <Casino />
    </div>
  )
}

export default Home
