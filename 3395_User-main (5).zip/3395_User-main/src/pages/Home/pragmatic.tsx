import { useEffect, useState, useRef } from "react";
import { useNavigate } from "react-router-dom";
import GameCard from "@/components/gamecard";
import { apiService, type Game } from "@/services/api";
import { useTheme } from "@/hooks/useTheme";

// Module-level cache to prevent duplicate API calls across Strict Mode remounts
let pragmaticGamesCache: { data: Game[] | null; timestamp: number } | null = null;
const CACHE_DURATION = 5000; // 5 seconds cache

const PragmaticGamesSection = () => {
  const navigate = useNavigate();
  const [games, setGames] = useState<Game[]>([]);
  const [error, setError] = useState<string | null>(null);
  const isMountedRef = useRef(true);
  const hasFetchedRef = useRef(false);
  const { themeConfig } = useTheme();

  useEffect(() => {
    isMountedRef.current = true;

    // Check cache first (prevents duplicate calls in Strict Mode)
    if (pragmaticGamesCache && Date.now() - pragmaticGamesCache.timestamp < CACHE_DURATION) {
      if (pragmaticGamesCache.data) {
        setGames(pragmaticGamesCache.data);
        hasFetchedRef.current = true;
        return;
      }
    }

    // Skip if already fetched in this render cycle
    if (hasFetchedRef.current) {
      return;
    }

    hasFetchedRef.current = true;

    const fetchGames = async () => {
      try {
        setError(null);
        const response = await apiService.getSlotGames({
          search: "",
          vendorCode: ["slot-pragmatic"],
          type: 2,
          page: 1,
          limit: 20,
        });
        
        // Only update state if component is still mounted
        if (!isMountedRef.current) return;
        
        if (response.status === 'ok' && response.data) {
          // Filter only games with launch_enable
          const enabledGames = response.data.data.filter(game => game.launch_enable);
          setGames(enabledGames);
          // Update cache
          pragmaticGamesCache = { data: enabledGames, timestamp: Date.now() };
        } else {
          setError(response.message || 'Failed to load games');
        }
      } catch (err: any) {
        // Don't update state if component unmounted
        if (!isMountedRef.current) return;
        
        setError(err.message || 'Failed to load games');
        console.error('Error fetching pragmatic games:', err);
      } finally {
        hasFetchedRef.current = false;
      }
    };

    fetchGames();

    return () => {
      isMountedRef.current = false;
    };
  }, []);

  return (
    <section className="py-6 px-4 bg-theme-primary">
      {/* Section Header */}
      <div className="flex items-center justify-between mb-4">
        <div className="relative flex items-center gap-2">
          <div className="relative">
            <div className="relative w-auto h-8">
              <img src="https://api.multiskinvs.pro/api/public/images/provider/slot-pragmatic.svg" alt="paramatic" className="h-full w-full" />
            </div>
          </div>
          <h2 
            className="text-lg md:text-xl font-bold"
            style={{ color: themeConfig?.header.selectedTextColor || '#ffffff' }}
          >
            Pragmatic Play
          </h2>
        </div>

        <button 
          onClick={() => navigate('/slots?view=pragmatic')}
          className="px-4 py-2 rounded-full font-medium text-sm transition-all duration-200 shadow-md hover:shadow-lg hover:brightness-110"
          style={{
            backgroundImage: 'linear-gradient(to right, var(--gradient-from), var(--gradient-to))',
            color: themeConfig?.header.selectedTextColor || '#ffffff',
          }}
        >
          Ver más
        </button>
      </div>

      {/* Blue line below header */}
      <div className="h-[2px] mb-4 w-12" style={{ backgroundColor: 'var(--scrollbar-thumb)' }}></div>

      {/* Games Carousel */}
      <div className="relative">
        {error ? (
          <div className="text-center py-8">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        ) : games.length === 0 ? null : (
          <div className="grid grid-cols-3 gap-3 md:gap-4 md:grid-cols-6 2xl:grid-cols-8">
            {games.map((game, index) => {
              // Show first 6 games on all screens
              // Show games 7-8 (index 6-7) only on 2xl screens (>= 1280px)
              if (index < 6) {
                return (
                  <div key={game._id} className="block">
                    <GameCard title={game.gameName} imageUrl={game.thumbnail} gameCode={game.gameCode} vendorCode="slot-pragmatic" />
                  </div>
                );
              } else if (index < 8) {
                // Games 7-8: visible only on 2xl screens
                return (
                  <div key={game._id} className="hidden 2xl:block">
                    <GameCard title={game.gameName} imageUrl={game.thumbnail} gameCode={game.gameCode} vendorCode="slot-pragmatic" />
                  </div>
                );
              } else {
                // Games beyond 8: hidden
                return null;
              }
            })}
          </div>
        )}

        {/* Fade edges */}
        <div className="absolute right-0 top-0 bottom-4 w-16 bg-gradient-to-l from-background to-transparent pointer-events-none" />
      </div>
    </section>
  );
};

export default PragmaticGamesSection;
