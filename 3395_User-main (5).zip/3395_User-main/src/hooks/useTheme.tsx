import { createContext, useContext, useEffect, useState, useRef, type ReactNode } from "react";
import { apiService } from "@/services/api";
import { getThemeConfig, type ThemeConfig } from "@/config/themeConfig";

interface ThemeContextType {
  theme: number | null;
  themeConfig: ThemeConfig | null;
  loading: boolean;
  refreshTheme: () => Promise<void>;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const STORAGE_KEY = 'user_theme';

export const ThemeProvider = ({ children }: { children: ReactNode }) => {
  const [theme, setTheme] = useState<number | null>(null);
  const [themeConfig, setThemeConfig] = useState<ThemeConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const hasFetchedRef = useRef(false);

  const applyTheme = (themeValue: number) => {
    const config = getThemeConfig(themeValue);
    setTheme(themeValue);
    setThemeConfig(config);
    
    // Apply theme to document
    document.documentElement.setAttribute('data-theme', themeValue.toString());
    
    // Apply CSS variables
    document.documentElement.style.setProperty('--bg-primary', config.colors.primary);
    document.documentElement.style.setProperty('--bg-secondary', config.colors.secondary);
    document.documentElement.style.setProperty('--bg-tertiary', config.colors.tertiary);
    document.documentElement.style.setProperty('--border-color', config.colors.border);
    // Apply scrollbar colors from theme
    document.documentElement.style.setProperty('--scrollbar-track', config.scrollbar.track);
    document.documentElement.style.setProperty('--scrollbar-thumb', config.scrollbar.thumb);
    // Apply gradient colors from theme
    document.documentElement.style.setProperty('--gradient-from', config.gradient.from);
    document.documentElement.style.setProperty('--gradient-to', config.gradient.to);
    // Apply text hover color from theme
    document.documentElement.style.setProperty('--text-hover', config.header.textHover);
    // Apply modal background color from theme
    document.documentElement.style.setProperty('--modal-bg', config.modal.backgroundColor);
    // Apply modal header color from theme
    document.documentElement.style.setProperty('--modal-header-color', config.modal.headerColor);
    // Apply modal button color from theme
    document.documentElement.style.setProperty('--modal-button-color', config.modal.buttonColor);
    // Apply input colors from theme
    document.documentElement.style.setProperty('--input-bg', config.input.backgroundColor);
    document.documentElement.style.setProperty('--input-border', config.input.borderColor);
    
    // Update favicon
    const updateFavicon = (href: string) => {
      // Remove all existing favicon links
      const existingLinks = document.querySelectorAll("link[rel~='icon']");
      existingLinks.forEach(link => link.remove());
      
      // Add new favicon link
      const link = document.createElement('link');
      link.rel = 'icon';
      link.type = 'image/png';
      link.href = href;
      document.head.appendChild(link);
      
      // Also update apple-touch-icon if exists
      const appleIcon = document.querySelector("link[rel~='apple-touch-icon']");
      if (appleIcon) {
        (appleIcon as HTMLLinkElement).href = href;
      }
    };
    
    updateFavicon(config.favicon.image);
  };

  const fetchTheme = async () => {
    // Skip if already fetched
    if (hasFetchedRef.current) {
      return;
    }

    hasFetchedRef.current = true;

    try {
      const response = await apiService.getTheme();
      if (response.status === 'ok' && response.data) {
        const themeValue = response.data.theme; 
        // const themeValue = 7; 
        localStorage.setItem(STORAGE_KEY, themeValue.toString());
        applyTheme(themeValue);
      } else {
        // If API response is not ok, try to use stored theme
        const storedTheme = localStorage.getItem(STORAGE_KEY);
        if (storedTheme) {
          const themeValue = parseInt(storedTheme, 10);
          applyTheme(themeValue);
        } else {
          // Default to theme 5 if API fails and no stored theme
          applyTheme(1);
        }
      }
    } catch (error) {
      console.error('Error fetching theme:', error);
      // Try to use stored theme if API fails
      const storedTheme = localStorage.getItem(STORAGE_KEY);
      if (storedTheme) {
        const themeValue = parseInt(storedTheme, 10);
        applyTheme(themeValue);
      } else {
        // Default to theme 5 if API fails and no stored theme
        applyTheme(1);
      }
    } finally {
      setLoading(false);
    }
  };

  const refreshTheme = async () => {
    // Reset ref to allow refresh
    hasFetchedRef.current = false;
    await fetchTheme();
  };

  useEffect(() => {
    // Check for stored theme first and apply immediately
    const storedTheme = localStorage.getItem(STORAGE_KEY);
    if (storedTheme) {
      const themeValue = parseInt(storedTheme, 10);
      applyTheme(themeValue);
    } else {
      // Default to theme 5 if no stored theme
      applyTheme(1);
    }

    // Fetch theme from API - this must complete before other APIs are called
    fetchTheme();
  }, []);

  // Don't render children until theme is loaded (or failed to load)
  // This ensures theme API is called first before other components mount
  if (loading) {
    return null; // or a loading spinner if preferred
  }

  return (
    <ThemeContext.Provider value={{ theme, themeConfig, loading, refreshTheme }}>
      {children}
    </ThemeContext.Provider>
  );
};

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (context === undefined) {
    throw new Error("useTheme must be used within a ThemeProvider");
  }
  return context;
};

