import { type ReactNode } from 'react';
import { useSocket } from './useSocket';

export const SocketProvider = ({ children }: { children: ReactNode }) => {
  // This hook will handle socket connection and balance updates
  useSocket();
  
  return <>{children}</>;
};
