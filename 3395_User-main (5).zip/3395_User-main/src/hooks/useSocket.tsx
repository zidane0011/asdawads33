import { useEffect, useRef } from 'react';
import { Socket } from 'socket.io-client';
import { useAuth } from './useAuth';
import { getSocket } from '@/services/socketClient';
import { SOCKET_CLIENT_CHANNEL } from '@/services/api';
import { SocketMessageCode, type SocketMessageType } from '@/shared/socket';

const HEARTBEAT_INTERVAL_MS = 10000;

export function useSocket(): Socket | null {
  const { accessToken, updateBalance } = useAuth();
  const heartbeatRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const authRef = useRef({ updateBalance });
  authRef.current = { updateBalance };

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const $io = getSocket();

    // Only connect when we have a token (same as 3332). Don't depend on user — balance updates change user and would reconnect on every message.
    if (!accessToken) {
      if ($io.connected) $io.disconnect();
      return;
    }

    ($io as Socket & { auth: Record<string, string> }).auth = { token: accessToken };
    $io.connect();

    $io.on('connect', () => {
      console.log('socket connected');
    });

    $io.on('disconnect', (err: unknown) => {
      console.log('socket disconnected', err);
      $io.disconnect();
    });

    $io.on(SOCKET_CLIENT_CHANNEL, (data: SocketMessageType & { code?: number | string }) => {
      const isValid =
        data &&
        data.body &&
        Object.values(SocketMessageCode).some((x) => x == data.code);

      if (!isValid) {
        console.error('invalid socket message :::', JSON.stringify(data));
        return;
      }

      const { code, body } = data;
      const { updateBalance: updateBalanceFn } = authRef.current;

      if (code === SocketMessageCode.USER_CASINO) {
        const balance = body?.balance;
        if (balance !== undefined && balance !== null) {
          const balanceStr = typeof balance === 'number' ? String(balance) : String(balance);
          updateBalanceFn(balanceStr);
        }
      } else if (code === SocketMessageCode.LOG_OUT) {
        // Logout via socket disabled: do not sign out when server sends LOG_OUT (e.g. on sports page)
      } else if (code === SocketMessageCode.HeartBeat) {
        console.log('received heartbeat');
      }
    });

    heartbeatRef.current = setInterval(() => {
      $io.emit(SOCKET_CLIENT_CHANNEL, { code: SocketMessageCode.HeartBeat });
    }, HEARTBEAT_INTERVAL_MS);

    return () => {
      if (heartbeatRef.current) {
        clearInterval(heartbeatRef.current);
        heartbeatRef.current = null;
      }
      $io.off('connect');
      $io.off('disconnect');
      $io.off(SOCKET_CLIENT_CHANNEL);
      if ($io.connected) $io.disconnect();
    };
  }, [accessToken]);

  return getSocket();
}
