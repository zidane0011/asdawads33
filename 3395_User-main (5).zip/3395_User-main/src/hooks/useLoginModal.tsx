import { createContext, useContext, useState, type ReactNode } from "react";

interface PendingGame {
  gameCode: string;
  vendorCode: string;
}

interface LoginModalContextType {
  isLoginOpen: boolean;
  pendingGame: PendingGame | null;
  pendingRedirectPath: string | null;
  openLoginModal: (gameCode?: string, vendorCode?: string, redirectPath?: string) => void;
  closeLoginModal: () => void;
  clearPendingGame: () => void;
}

const LoginModalContext = createContext<LoginModalContextType | undefined>(undefined);

export const LoginModalProvider = ({ children }: { children: ReactNode }) => {
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [pendingGame, setPendingGame] = useState<PendingGame | null>(null);
  const [pendingRedirectPath, setPendingRedirectPath] = useState<string | null>(null);

  const openLoginModal = (gameCode?: string, vendorCode?: string, redirectPath?: string) => {
    setIsLoginOpen(true);
    if (gameCode && vendorCode) {
      setPendingGame({ gameCode, vendorCode });
      setPendingRedirectPath(null);
    } else {
      setPendingGame(null);
      setPendingRedirectPath(redirectPath ?? null);
    }
  };

  const closeLoginModal = () => {
    setIsLoginOpen(false);
    setPendingRedirectPath(null);
  };

  const clearPendingGame = () => {
    setPendingGame(null);
  };

  return (
    <LoginModalContext.Provider value={{ isLoginOpen, pendingGame, pendingRedirectPath, openLoginModal, closeLoginModal, clearPendingGame }}>
      {children}
    </LoginModalContext.Provider>
  );
};

export const useLoginModal = () => {
  const context = useContext(LoginModalContext);
  if (context === undefined) {
    throw new Error("useLoginModal must be used within a LoginModalProvider");
  }
  return context;
};

