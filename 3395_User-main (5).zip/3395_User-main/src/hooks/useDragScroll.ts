import { useRef, useEffect } from 'react';

export const useDragScroll = () => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const isDown = useRef(false);
  const startX = useRef(0);
  const scrollLeft = useRef(0);
  const hasMoved = useRef(false);
  const MOVE_THRESHOLD = 5; // Minimum pixels to move before considering it a drag

  useEffect(() => {
    const slider = scrollRef.current;
    if (!slider) return;

    const handleMouseDown = (e: MouseEvent) => {
      // Always allow dragging to start
      isDown.current = true;
      hasMoved.current = false;
      slider.style.cursor = 'grabbing';
      slider.style.userSelect = 'none';
      const rect = slider.getBoundingClientRect();
      startX.current = e.pageX - rect.left;
      scrollLeft.current = slider.scrollLeft;
    };

    const handleMouseLeave = () => {
      isDown.current = false;
      hasMoved.current = false;
      slider.style.cursor = 'grab';
      slider.style.userSelect = '';
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (!isDown.current) return;
      
      // If we moved significantly, prevent click events
      if (hasMoved.current) {
        e.preventDefault();
        e.stopPropagation();
      }
      isDown.current = false;
      hasMoved.current = false;
      slider.style.cursor = 'grab';
      slider.style.userSelect = '';
    };

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDown.current) return;
      const rect = slider.getBoundingClientRect();
      const x = e.pageX - rect.left;
      const walk = (x - startX.current) * 2; // Scroll speed multiplier
      const moveDistance = Math.abs(x - startX.current);
      
      // Mark as moved if beyond threshold
      if (moveDistance > MOVE_THRESHOLD) {
        hasMoved.current = true;
      }
      
      // Scroll immediately when dragging (even before threshold)
      if (isDown.current) {
        e.preventDefault();
        slider.scrollLeft = scrollLeft.current - walk;
      }
    };

    // Touch events
    const handleTouchStart = (e: TouchEvent) => {
      // Always allow dragging to start
      isDown.current = true;
      hasMoved.current = false;
      startX.current = e.touches[0].pageX - slider.offsetLeft;
      scrollLeft.current = slider.scrollLeft;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (!isDown.current) return;
      const x = e.touches[0].pageX - slider.offsetLeft;
      const walk = (x - startX.current) * 2; // Scroll speed multiplier
      const moveDistance = Math.abs(x - startX.current);
      
      // Mark as moved if beyond threshold
      if (moveDistance > MOVE_THRESHOLD) {
        hasMoved.current = true;
      }
      
      // Always scroll if we're dragging
      if (hasMoved.current) {
        e.preventDefault();
        slider.scrollLeft = scrollLeft.current - walk;
      }
    };

    const handleTouchEnd = (e: TouchEvent) => {
      // If we moved significantly, prevent click events
      if (hasMoved.current) {
        e.preventDefault();
        e.stopPropagation();
      }
      isDown.current = false;
      hasMoved.current = false;
    };

    // Mouse events - use capture phase for mousedown to catch events before child elements
    slider.addEventListener('mousedown', handleMouseDown, true);
    slider.addEventListener('mouseleave', handleMouseLeave);
    
    // Attach mousemove and mouseup to document to catch events even when mouse leaves the element
    document.addEventListener('mousemove', handleMouseMove);
    document.addEventListener('mouseup', handleMouseUp);
    
    // Also listen for click events to prevent them if we dragged
    const handleClick = (e: MouseEvent) => {
      if (hasMoved.current) {
        e.preventDefault();
        e.stopPropagation();
        e.stopImmediatePropagation();
      }
    };
    slider.addEventListener('click', handleClick, true);

    // Touch events - use capture phase for touchstart
    slider.addEventListener('touchstart', handleTouchStart, { passive: false, capture: true });
    slider.addEventListener('touchmove', handleTouchMove, { passive: false });
    slider.addEventListener('touchend', handleTouchEnd);

    // Set initial cursor
    slider.style.cursor = 'grab';

    return () => {
      slider.removeEventListener('mousedown', handleMouseDown, true);
      slider.removeEventListener('mouseleave', handleMouseLeave);
      document.removeEventListener('mousemove', handleMouseMove);
      document.removeEventListener('mouseup', handleMouseUp);
      slider.removeEventListener('click', handleClick, true);
      slider.removeEventListener('touchstart', handleTouchStart, true);
      slider.removeEventListener('touchmove', handleTouchMove);
      slider.removeEventListener('touchend', handleTouchEnd);
    };
  }, []);

  return scrollRef;
};

