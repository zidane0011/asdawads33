import { createContext, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { apiService } from "@/services/api";
import { disconnectSocket } from "@/services/socketClient";
import type { LoginResponse, ProfileResponse } from "@/services/api";

export interface User {
  avatar: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  loginId: string;
  balance: string;
}

interface AuthContextType {
  user: User | null;
  accessToken: string | null;
  loading: boolean;
  signIn: (loginId: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (loginId: string, password: string, username: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  updateBalance: (balance: string) => void;
  updateProfile: (profile: User) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const STORAGE_KEYS = {
  ACCESS_TOKEN: 'access_token',
  USER_PROFILE: 'user_profile',
};

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for existing session on mount
    const storedToken = localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
    const storedProfile = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);

    if (storedToken && storedProfile) {
      try {
        const profile = JSON.parse(storedProfile);
        setAccessToken(storedToken);
        setUser(profile);
        
        // Verify token is still valid and fetch fresh profile data
        apiService.verify()
          .then(() => {
            // Token is valid, fetch fresh profile from backend
            console.log('[Auth] 🔄 Token verified, fetching fresh profile from backend...');
            return apiService.getProfile();
          })
          .then((response: ProfileResponse) => {
            if (response.status === 'ok' && response.data) {
              console.log('[Auth] ✅ Fresh profile data received:', response.data);
              // Update user state with fresh data (balance and avatar)
              const freshProfile: User = {
                avatar: response.data.avatar,
                firstName: response.data.firstName,
                lastName: response.data.lastName,
                email: response.data.email,
                phoneNumber: response.data.phoneNumber,
                loginId: response.data.loginId,
                balance: response.data.balance,
              };
              setUser(freshProfile);
              // Update localStorage with fresh data
              localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(freshProfile));
              console.log('[Auth] ✅ Profile updated with fresh data from backend');
            }
          })
          .catch((error) => {
            console.error('[Auth] ❌ Error verifying token or fetching profile:', error);
            // Token invalid or fetch failed, clear storage
            localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
            localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
            setAccessToken(null);
            setUser(null);
          });
      } catch (error) {
        // Invalid stored data, clear it
        console.error('[Auth] ❌ Error parsing stored profile:', error);
        localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
        localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
      }
    }
    
    setLoading(false);
  }, []);

  const signIn = async (loginId: string, password: string) => {
    try {
      const response: LoginResponse = await apiService.login({ loginId, password });
      
      if (response.status === 'ok' && response.data) {
        const { access_token, profile } = response.data;
        
        // Store token and profile
        localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, access_token);
        localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
        
        setAccessToken(access_token);
        setUser(profile);
        
        return { error: null };
      } else {
        return { error: new Error(response.message || 'Login failed') };
      }
    } catch (error: any) {
      return { error: error as Error };
    }
  };

  const signUp = async (_loginId: string, _password: string, _username: string) => {
    // Note: The API doesn't have a signup endpoint in the provided docs
    // For now, we'll return an error indicating signup is not available
    // You can implement this later if the API provides a signup endpoint
    return { error: new Error('Sign up is not available through the API') };
  };

  const signOut = async () => {
    try {
      await apiService.logout();
    } catch (error) {
      // Even if logout fails, clear local state
      console.error('Logout error:', error);
    } finally {
      disconnectSocket();
      localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
      localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
      setAccessToken(null);
      setUser(null);
    }
  };

  const updateBalance = (balance: string) => {
    console.log('[Auth] 🔄 updateBalance called with:', balance);
    console.log('[Auth] 🔄 Current user state:', user);
    
    if (user) {
      console.log('[Auth] ✅ User exists, updating balance');
      const updatedUser = { ...user, balance };
      console.log('[Auth] ✅ Updated user object:', updatedUser);
      
      setUser(updatedUser);
      console.log('[Auth] ✅ setUser called with new balance:', balance);
      
      // Update stored profile as well
      localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(updatedUser));
      console.log('[Auth] ✅ localStorage updated with new balance');
      
      // Verify localStorage was updated
      const stored = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      console.log('[Auth] ✅ Verification - localStorage contains:', stored);
    } else {
      console.warn('[Auth] ⚠️ Cannot update balance: user is null');
    }
  };

  const updateProfile = (profile: User) => {
    console.log('[Auth] 🔄 updateProfile called with:', profile);
    
    setUser(profile);
    // Update stored profile as well
    localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
    console.log('[Auth] ✅ Profile updated in state and localStorage');
  };

  return (
    <AuthContext.Provider value={{ user, accessToken, loading, signIn, signUp, signOut, updateBalance, updateProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
