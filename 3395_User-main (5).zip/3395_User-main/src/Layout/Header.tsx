import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { User } from "lucide-react";
import { Button } from "@/components/button";
import { cn } from "@/lib/utils";
import LoginModal from "@/pages/LoginModal";
import ProfileModal from "@/pages/ProfileModal";
import { useAuth } from "@/hooks/useAuth";
import { useLoginModal } from "@/hooks/useLoginModal";
import { useTheme } from "@/hooks/useTheme";

const navItems = [
  { label: "Home", href: "/" },
  { label: "Slots", href: "/slots" },
  { label: "Casino online", href: "/casino" },
  { label: "Deportes", href: "/sports" },
  { label: "Minijuego", href: "/minigame" },
];

const tickerMessages = [
  "🎉 Bienvenido a Bet30 – La mejor plataforma de apuestas online",
  "⚽ Real Madrid vs Arsenal – Apuesta ahora y gana grandes premios",
  "🏆 Licencia Curacao eGaming – Juega con total seguridad",
  "🎰 Más de 500 juegos disponibles – Slots, Casino en vivo y más",
  "🔥 Bono de bienvenida del 100% en tu primer depósito",
  "🎮 Game Check Certificado – Juego responsable garantizado",
  "⚡ Retiros rápidos en menos de 24 horas – Sin complicaciones",
  "🌟 Lyon, Benfica, AC Milan – Tus equipos favoritos te esperan",
];

const Header = () => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const { user, signOut } = useAuth();
  const { isLoginOpen, openLoginModal, closeLoginModal } = useLoginModal();
  const { themeConfig } = useTheme();

  const getActiveItem = () => {
    const currentPath = location.pathname;
    const activeNavItem = navItems.find(item => item.href === currentPath);
    return activeNavItem ? activeNavItem.label : "Home";
  };

  const activeItem = getActiveItem();

  const handleAuthClick = () => {
    if (user) {
      signOut();
    } else {
      openLoginModal();
    }
  };

  const tickerText = tickerMessages.join("   •   ");

  return (
    <>
      {/* Animated Ticker Banner */}
      <div
        className="fixed top-0 left-0 right-0 z-[60] overflow-hidden"
        style={{
          background: `linear-gradient(90deg, ${themeConfig?.gradient?.from || '#021b79'}, ${themeConfig?.gradient?.to || '#0575e6'})`,
          height: "28px",
        }}
      >
        <style>{`
          @keyframes ticker-scroll {
            0% { transform: translateX(0); }
            100% { transform: translateX(-33.333%); }
          }
          .ticker-content {
            animation: ticker-scroll 45s linear infinite;
            will-change: transform;
            display: inline-block;
          }
          .ticker-content:hover {
            animation-play-state: paused;
          }
        `}</style>
        <div className="h-full flex items-center overflow-hidden">
          <div className="ticker-content whitespace-nowrap text-white text-xs font-medium tracking-wide">
            {tickerText}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{tickerText}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{tickerText}
          </div>
        </div>
      </div>

      <header
        className="fixed w-full z-50 backdrop-blur-md left-0 right-0"
        style={{
          top: "28px",
          backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
          color: themeConfig?.header.textColor || '#ffffff'
        }}
      >
        <div className="flex items-center justify-between h-16 px-4 w-full max-w-full">
          <Link to="/" className="flex items-center">
            <img
              src={themeConfig?.logo.image || '/logo.png'}
              alt="Bet30 Logo"
              className="h-8 lg:h-10"
            />
          </Link>

          <nav className="hidden md:flex items-center gap-2 lg:gap-10 xl:gap-20">
            {navItems.map((item) => (
              <Link
                key={item.label}
                to={item.href}
                className={cn(
                  "px-2 lg:px-4 py-2 rounded-full text-sm font-medium transition-all duration-200",
                  activeItem === item.label
                    ? "bg-gradient-menu-active shadow-glow-primary"
                    : "hover:text-hover"
                )}
                style={{
                  color: activeItem === item.label
                    ? themeConfig?.header.selectedTextColor || '#ffffff'
                    : themeConfig?.header.textColor || '#ffffff'
                }}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-2">
                <div
                  className="px-3 py-2 rounded-full border-2 text-sm font-medium"
                  style={{
                    backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                    borderColor: themeConfig?.header.borderColor || '#27287e',
                    color: themeConfig?.header.textColor || '#ffffff',
                  }}
                >
                  $ {user.balance || "0.00"} ARS
                </div>
                <button
                  onClick={() => setIsProfileOpen(true)}
                  className="flex items-center justify-center w-10 h-10 rounded-full border-2 hover:opacity-80 transition-opacity cursor-pointer"
                  style={{
                    backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
                    borderColor: themeConfig?.header.borderColor || '#27287e',
                  }}
                >
                  <User className="w-5 h-5" style={{ color: themeConfig?.header.textColor || '#ffffff' }} />
                </button>
              </div>
            ) : (
              <Button
                onClick={handleAuthClick}
                className="flex items-center gap-2 px-4 md:px-6 rounded-full bg-gradient-menu-active hover:opacity-90 shadow-glow-primary text-sm md:text-base"
                style={{ color: themeConfig?.header.selectedTextColor || '#ffffff' }}
              >
                <span>Acceder</span>
                <User className="w-4 h-4 md:w-5 md:h-5" />
              </Button>
            )}
          </div>
        </div>

        {isMobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-border" style={{ color: themeConfig?.header.textColor || '#E0E0E0' }}>
            <div className="flex flex-col gap-2">
              {navItems.map((item) => (
                <Link
                  key={item.label}
                  to={item.href}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    "px-4 py-3 rounded-lg text-sm font-medium transition-all duration-200 hover:bg-gradient-menu-active",
                    activeItem === item.label ? "bg-gradient-primary" : ""
                  )}
                  style={{ color: themeConfig?.header.textColor || '#E0E0E0' }}
                >
                  {item.label}
                </Link>
              ))}
              {user && (
                <button
                  onClick={() => { setIsProfileOpen(true); setIsMobileMenuOpen(false); }}
                  className="px-4 py-3 rounded-lg text-sm font-medium hover:bg-gradient-menu-active transition-all text-left w-full"
                  style={{ color: themeConfig?.header.textColor || '#E0E0E0' }}
                >
                  <User className="w-4 h-4 inline mr-2" />Perfil
                </button>
              )}
              <Button
                onClick={() => { handleAuthClick(); setIsMobileMenuOpen(false); }}
                className="mt-2 bg-gradient-primary hover:bg-gradient-menu-active"
                style={{ color: themeConfig?.header.selectedTextColor || '#ffffff' }}
              >
                <User className="w-4 h-4 mr-2" />
                {user ? "Cerrar sesión" : "Acceder"}
              </Button>
            </div>
          </nav>
        )}
      </header>

      <LoginModal isOpen={isLoginOpen} onClose={closeLoginModal} />
      <ProfileModal isOpen={isProfileOpen} onClose={() => setIsProfileOpen(false)} />
    </>
  );
};

export default Header;
