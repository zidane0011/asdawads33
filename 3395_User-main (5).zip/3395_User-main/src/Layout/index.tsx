import { Outlet, useLocation } from "react-router";
import Header from "./Header";
import Footer from "./Footer";
import MobileMenu from "./MobileMenu";

const Layout = () => {
    const location = useLocation();
    const isGameDetailPage = location.pathname === "/game";
    const isSportsPage = location.pathname === "/sports";
    const showFooter = !isGameDetailPage && !isSportsPage;
    const showMobileMenu = !isGameDetailPage;

    return (
        <div className="min-h-screen flex flex-col justify-between w-full overflow-x-hidden">
            <Header />
           <div className="pt-[calc(4rem+28px)] w-full overflow-x-hidden">
                <Outlet />
            </div>
            {showFooter && <Footer />}
            {showMobileMenu && <MobileMenu />}
        </div>
    )
}

export default Layout;
