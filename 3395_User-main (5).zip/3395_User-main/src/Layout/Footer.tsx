import { Link } from "react-router-dom";

function Footer() {
  const whatsappSupportUrl = import.meta.env.VITE_WHATSAPP_SUPPORT_URL ?? "https://wa.me/542244428594";

  const casinoLinks = [
    { label: "Slots", href: "/slots" },
    { label: "Favoritos", href: "/slots" },
    { label: "Nuevos", href: "/slots" },
    { label: "Bingo", href: "/casino" },
    { label: "Lotería", href: "/casino" },
    { label: "Crash", href: "/casino" }
  ];

  const liveCasinoLinks = [
    { label: "Slots", href: "/slots" },
    { label: "Favoritos", href: "/slots" },
    { label: "Nuevos", href: "/slots" },
    { label: "Ruleta", href: "/casino" },
    { label: "Blackjack", href: "/casino" },
    { label: "Poker", href: "/casino" }
  ];

  const utilesLinks = [
    { label: "Deportes", href: "/sports" },
    { label: "Pragmatic", href: "/slots?view=pragmatic" },
    { label: "Ruby", href: "/slots?view=rubyplay" },
    { label: "Aviatrix", href: "/casino" },
    { label: "RedDrake", href: "/casino" },
    { label: "KaGaming", href: "/slots?view=kagaming" }
  ];

  const teamLogos = [
    {
      name: "Real Madrid",
      url: "https://www.aia.com/en",
      logo: "https://upload.wikimedia.org/wikipedia/en/5/56/Real_Madrid_CF.svg",
    },
    {
      name: "Lyon",
      url: "https://www.aia.com/en",
      logo: "https://upload.wikimedia.org/wikipedia/en/b/ba/Olympique_Lyonnais.svg",
    },
    {
      name: "Benfica",
      url: "https://www.aia.com/en",
      logo: "https://upload.wikimedia.org/wikipedia/en/thumb/8/8e/S.L._Benfica.svg/128px-S.L._Benfica.svg.png",
    },
    {
      name: "Arsenal",
      url: "https://www.aia.com/en",
      logo: "https://upload.wikimedia.org/wikipedia/en/5/53/Arsenal_FC.svg",
    },
    {
      name: "AC Milan",
      url: "https://www.aia.com/en",
      logo: "https://upload.wikimedia.org/wikipedia/commons/d/d0/Logo_of_AC_Milan.svg",
    },
  ];

  const socialLinks = [
    {
      name: "Instagram",
      url: "https://instagram.com",
      icon: (
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
        </svg>
      ),
      color: "#E1306C",
    },
    {
      name: "Twitter/X",
      url: "https://x.com",
      icon: (
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-4.714-6.231-5.401 6.231H2.744l7.73-8.835L1.254 2.25H8.08l4.713 5.887zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
        </svg>
      ),
      color: "#000000",
    },
    {
      name: "Facebook",
      url: "https://facebook.com",
      icon: (
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
        </svg>
      ),
      color: "#1877F2",
    },
    {
      name: "Telegram",
      url: "https://telegram.org",
      icon: (
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/>
        </svg>
      ),
      color: "#0088cc",
    },
    {
      name: "YouTube",
      url: "https://youtube.com",
      icon: (
        <svg viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
          <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
        </svg>
      ),
      color: "#FF0000",
    },
  ];

  return (
    <>
      <footer className="bg-theme-secondary text-white py-8 md:py-12 px-10 w-full overflow-x-hidden max-w-full mb-16 md:mb-0">
        <div className="w-full max-w-full">

          {/* Ana Footer Linkleri */}
          <div className="flex flex-col md:grid md:grid-cols-3 gap-8 mb-8">
            <div className="flex gap-6 sm:gap-12 md:gap-3 lg:gap-6 xl:gap-12 justify-center md:justify-start">
              <div className="flex flex-col gap-3 items-center">
                <h3 className="text-lg md:text-base lg:text-lg font-semibold mb-2">Casino</h3>
                <ul className="flex flex-col gap-2 items-center justify-start">
                  {casinoLinks.map((link, index) => (
                    <li key={index}>
                      <Link to={link.href} className="text-sm md:text-xs lg:text-sm text-gray-300 hover:text-white transition-colors">
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-col gap-3">
                <h3 className="text-lg md:text-base lg:text-lg font-semibold mb-2">Live Casino</h3>
                <ul className="flex flex-col gap-2">
                  {liveCasinoLinks.map((link, index) => (
                    <li key={index}>
                      <Link to={link.href} className="text-sm md:text-xs lg:text-sm text-gray-300 hover:text-white transition-colors">
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div className="flex flex-col gap-3">
                <h3 className="text-lg md:text-base lg:text-lg font-semibold mb-2">Utiles</h3>
                <ul className="flex flex-col gap-2">
                  {utilesLinks.map((link, index) => (
                    <li key={index}>
                      <Link to={link.href} className="text-sm md:text-xs lg:text-sm text-gray-300 hover:text-white transition-colors">
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="flex items-center justify-center">
              <img src="/logo_theme1.png" alt="Bet30 Logo" className="h-10 md:h-16 lg:h-20 w-auto" />
            </div>

            <div className="flex items-center gap-6 justify-between md:justify-end">
              <div className="flex flex-col items-center md:items-end gap-3">
                <p className="text-xs lg:text-sm text-gray-300 text-center md:text-right">¿Necesitas ayuda?</p>
                <a href={whatsappSupportUrl} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-2 hover:opacity-90 transition-opacity">
                  <div className="w-10 h-10 lg:w-12 lg:h-12 bg-[#25D366] rounded-full flex items-center justify-center shadow-lg">
                    <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp" className="w-full h-full object-contain" />
                  </div>
                  <span className="text-xs lg:text-sm font-medium text-white">WhatsApp</span>
                </a>
              </div>
              <div className="flex flex-col items-center md:items-end gap-2">
                <svg className="w-14 h-auto" viewBox="0 0 329 329" version="1.1" xmlns="http://www.w3.org/2000/svg"><g stroke="none" strokeWidth="1" fill="none" fillRule="evenodd"><g fill="#FFFFFF" fillRule="nonzero"><polygon points="104.032 220.434 104.032 131.15 83.392 131.15 83.392 108.27 132.513 108.27 132.513 220.434"></polygon><path d="M239.552,137.23 C239.552,146.99 234.272,155.63 225.472,160.431 C237.791,165.55 245.472,176.271 245.472,188.751 C245.472,208.911 227.551,221.712 199.551,221.712 C171.55,221.712 153.63,209.071 153.63,189.232 C153.63,176.431 161.95,165.55 174.91,160.431 C165.47,155.15 159.39,146.191 159.39,136.431 C159.39,118.509 175.071,107.15 199.391,107.15 C224.031,107.15 239.552,118.83 239.552,137.23 Z M180.51,186.352 C180.51,195.793 187.231,201.073 199.551,201.073 C211.871,201.073 218.751,195.954 218.751,186.352 C218.751,177.073 211.871,171.791 199.551,171.791 C187.23,171.791 180.51,177.072 180.51,186.352 Z M183.391,138.83 C183.391,146.832 189.151,151.31 199.551,151.31 C209.951,151.31 215.711,146.831 215.711,138.83 C215.711,130.512 209.951,125.871 199.551,125.871 C189.15,125.871 183.391,130.512 183.391,138.83 Z"></path><path d="M292.864,120.932 C297.599,134.907 300.001,149.524 300.001,164.432 C300.001,239.184 239.185,300 164.432,300 C89.679,300 28.862,239.184 28.862,164.432 C28.862,89.678 89.678,28.864 164.431,28.864 C179.341,28.864 193.958,31.264 207.931,36.001 L207.931,5.832 C193.817,1.963 179.24,0 164.432,0 C73.765,0 0.001,73.764 0.001,164.432 C0.001,255.1 73.765,328.864 164.432,328.864 C255.099,328.864 328.862,255.1 328.862,164.432 C328.862,149.625 326.9,135.047 323.031,120.932 L292.864,120.932 Z"></path><polygon points="284.659 44.111 284.659 12.582 261.987 12.582 261.987 44.111 230.647 44.111 230.647 66.781 261.987 66.781 261.987 98.309 284.659 98.309 284.659 66.781 316.186 66.781 316.186 44.111"></polygon></g></g></svg>
                <p className="text-xs text-gray-300 text-center md:text-right max-w-[120px]">Solo mayores de 18 años</p>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-700 my-6"></div>

          {/* Takım Logoları */}
          <div className="mb-6">
            <h4 className="text-xs text-gray-400 uppercase tracking-widest mb-3 text-center">Patrocinadores Deportivos</h4>
            <div className="flex flex-wrap items-center justify-center gap-4">
              {teamLogos.map((team) => (
                <a key={team.name} href={team.url} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center gap-1 group cursor-pointer" title={team.name}>
                  <div className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-white/5 border border-gray-700 flex items-center justify-center p-1.5 group-hover:border-blue-400 group-hover:bg-white/10 transition-all duration-200 overflow-hidden">
                    <img src={team.logo} alt={team.name} className="w-full h-full object-contain" onError={(e) => { (e.target as HTMLImageElement).src = '/logo.png'; }} />
                  </div>
                  <span className="text-[9px] text-gray-400 group-hover:text-white transition-colors">{team.name}</span>
                </a>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-700 my-6"></div>

          {/* Sosyal Medya */}
          <div className="mb-6">
            <h4 className="text-xs text-gray-400 uppercase tracking-widest mb-3 text-center">Síguenos</h4>
            <div className="flex flex-wrap items-center justify-center gap-3">
              {socialLinks.map((social) => (
                
                  key={social.name}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-3 py-2 rounded-full border border-gray-700 bg-gray-900/50 hover:scale-105 transition-all duration-200"
                  title={social.name}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = social.color;
                    (e.currentTarget as HTMLAnchorElement).style.color = social.color;
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLAnchorElement).style.borderColor = '';
                    (e.currentTarget as HTMLAnchorElement).style.color = '';
                  }}
                >
                  <span className="text-gray-400">{social.icon}</span>
                  <span className="text-xs text-gray-300 hidden sm:inline">{social.name}</span>
                </a>
              ))}
            </div>
          </div>

          <div className="border-t border-gray-700 my-6"></div>

          {/* Lisanslar & Partnerlar */}
          <div className="mb-6">
            <div className="flex flex-col md:flex-row items-center justify-center gap-8">

              {/* Lisanslar */}
              <div className="flex flex-col items-center gap-2">
                <h4 className="text-xs text-gray-400 uppercase tracking-widest mb-1">Licencias</h4>
                <div className="flex flex-wrap items-center justify-center gap-3">

                  {/* Curacao */}
                  <div className="flex flex-col items-center gap-1 px-3 py-2 rounded-lg border border-gray-700 bg-gray-900/50 hover:border-blue-500 transition-colors cursor-pointer min-w-[90px]">
                    <svg viewBox="0 0 48 48" className="w-8 h-8" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="24" cy="24" r="22" fill="#003087" stroke="#FFD700" strokeWidth="2"/>
                      <text x="24" y="20" textAnchor="middle" fill="#FFD700" fontSize="7" fontWeight="bold" fontFamily="Arial">CURACAO</text>
                      <text x="24" y="29" textAnchor="middle" fill="#FFFFFF" fontSize="5.5" fontFamily="Arial">eGAMING</text>
                      <path d="M14 33 L24 38 L34 33" stroke="#FFD700" strokeWidth="1.5" fill="none"/>
                    </svg>
                    <span className="text-[9px] text-gray-300 text-center leading-tight font-medium">Curacao<br/>Licensed</span>
                  </div>

                  {/* Amatic */}
                  <div className="flex flex-col items-center gap-1 px-3 py-2 rounded-lg border border-gray-700 bg-gray-900/50 hover:border-green-500 transition-colors cursor-pointer min-w-[90px]">
                    <svg viewBox="0 0 48 48" className="w-8 h-8" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <rect x="2" y="2" width="44" height="44" rx="8" fill="#1A1A2E" stroke="#00C851" strokeWidth="2"/>
                      <text x="24" y="19" textAnchor="middle" fill="#00C851" fontSize="8" fontWeight="bold" fontFamily="Arial">AMATIC</text>
                      <text x="24" y="29" textAnchor="middle" fill="#FFFFFF" fontSize="5.5" fontFamily="Arial">INDUSTRIES</text>
                      <text x="24" y="38" textAnchor="middle" fill="#00C851" fontSize="5" fontFamily="Arial">LICENSED</text>
                    </svg>
                    <span className="text-[9px] text-gray-300 text-center leading-tight font-medium">Amatic<br/>Licensed</span>
                  </div>

                  {/* Game Check */}
                  <div className="flex flex-col items-center gap-1 px-3 py-2 rounded-lg border border-gray-700 bg-gray-900/50 hover:border-purple-500 transition-colors cursor-pointer min-w-[90px]">
                    <svg viewBox="0 0 48 48" className="w-8 h-8" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <circle cx="24" cy="24" r="22" fill="#2D1B69" stroke="#9B59B6" strokeWidth="2"/>
                      <path d="M14 24 L20 30 L34 18" stroke="#9B59B6" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                      <text x="24" y="42" textAnchor="middle" fill="#9B59B6" fontSize="5" fontFamily="Arial" fontWeight="bold">GAME CHECK</text>
                    </svg>
                    <span className="text-[9px] text-gray-300 text-center leading-tight font-medium">Game<br/>Check</span>
                  </div>

                </div>
              </div>

              <div className="hidden md:block w-px h-20 bg-gray-700"></div>

              {/* Partnerlar */}
              <div className="flex flex-col items-center gap-2">
                <h4 className="text-xs text-gray-400 uppercase tracking-widest mb-1">Partners</h4>
                <div className="flex flex-wrap items-center justify-center gap-3">

                  {/* EGT */}
                  <div className="flex items-center justify-center px-4 py-2 rounded-lg border border-gray-700 bg-gray-900/50 hover:border-yellow-500 transition-colors cursor-pointer h-14 min-w-[80px]">
                    <svg viewBox="0 0 80 30" className="h-7 w-auto" xmlns="http://www.w3.org/2000/svg">
                      <rect width="80" height="30" rx="4" fill="#1a1a2e"/>
                      <text x="40" y="22" textAnchor="middle" fill="#FFD700" fontSize="18" fontWeight="900" fontFamily="Arial Black, Arial" letterSpacing="2">EGT</text>
                    </svg>
                  </div>

                  {/* Betsoft */}
                  <div className="flex items-center justify-center px-4 py-2 rounded-lg border border-gray-700 bg-gray-900/50 hover:border-red-500 transition-colors cursor-pointer h-14 min-w-[100px]">
                    <img
                      src="/providers/betsoft.png"
                      alt="Betsoft"
                      className="h-8 w-auto object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).style.display = 'none';
                      }}
                    />
                  </div>

                </div>
              </div>

            </div>
          </div>

          <div className="border-t border-gray-700 my-6"></div>

          <div className="text-center text-sm text-gray-400 pt-4">
            © 2026 Todos los derechos reservados.
          </div>

        </div>
      </footer>

      {/* WhatsApp Floating Button */}
      
        href={whatsappSupportUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-20 right-2 md:bottom-10 md:right-6 w-14 h-14 rounded-full flex items-center justify-center shadow-lg transition-all hover:scale-110 hover:brightness-110 z-50"
        style={{ backgroundImage: 'linear-gradient(to right, var(--gradient-from), var(--gradient-to))' }}
        aria-label="Open WhatsApp support chat"
      >
        <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" alt="WhatsApp" className="w-8 h-8" />
      </a>
    </>
  );
}

export default Footer;
