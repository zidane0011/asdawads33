import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { cn } from "@/lib/utils";
import { useTheme } from "@/hooks/useTheme";

const menuItems = [
  {
    label: "Casino",
    href: "/slots",
      icon: (
        <svg
          className="w-6 h-6 transition-opacity duration-300"
          width="20"
          height="20"
          viewBox="0 0 64 64"
          fill="currentColor"
          xmlns="http://www.w3.org/2000/svg"
        >
          <title>Casino</title>
          <path d="M12.265 47.726.21 14.603a3.574 3.574 0 0 1 2.108-4.553l.024-.007 19.282-7.015a3.55 3.55 0 0 1 4.553 2.082l.008.024.694 1.92L12.69 46.073a8.9 8.9 0 0 0-.418 1.598l-.008.056ZM63.79 15.511 48.002 58.93a3.529 3.529 0 0 1-4.558 2.1l.024.009-21.948-8.001a3.58 3.58 0 0 1-2.124-4.585l-.008.024 15.787-43.39a3.555 3.555 0 0 1 4.559-2.126l-.024-.008 21.948 8a3.58 3.58 0 0 1 2.124 4.585l.008-.024v-.002ZM50.457 32.685l-1.386-3.254a1.789 1.789 0 0 0-2.333-.956l.012-.004-2.666 1.174a1.787 1.787 0 0 1-2.316-.948l-.004-.012-1.146-2.667a1.764 1.764 0 0 0-2.332-.93l.012-.004-3.28 1.386a1.738 1.738 0 0 0-.929 2.33l-.004-.01 3.92 9.255a1.816 1.816 0 0 0 2.359.928l-.012.005 9.227-3.947a1.737 1.737 0 0 0 .794-2.356l.004.01h.08Z" />
        </svg>
      ),
  },
  {
    label: "Sports",
    href: "/sports",
    icon: (
      <svg
        className="w-6 h-6 transition-opacity duration-300"
        width="20"
        height="20"
        viewBox="0 0 96 96"
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
      >
        <title>Sports</title>
        <path
          clipRule="evenodd"
          d="M14.287 13.917c16.599 6.854 30.869 15.965 43.231 27.143l-.001.002.126.11-.125-.112C64.262 31 65.501 17.31 60.63 1.865 56.773.739 52.34.092 47.758.092c-13.046 0-24.87 5.249-33.47 13.748v.077Zm79.997 46.514a46.803 46.803 0 0 1-7.907 15.996v-.003c-2.275-3.87-4.709-7.622-7.185-11.295l-.137.08c4.463-2.823 9.63-4.63 15.307-5.11l-.078.332ZM80.986 82.734c-4.75 4.553-10.46 8.116-17.124 10.458h-.003l.006-.108a38.977 38.977 0 0 1 9.137-22.842l-.281-.41c2.838 3.924 5.478 8.005 8.265 12.902Zm0 0 .016-.014-.015.015ZM12.017 64.772a83.99 83.99 0 0 0 9.697.599h.003l-.117-.006c.832.039 1.674.06 2.518.06 12.98 0 24.848-4.766 33.883-12.589a132.455 132.455 0 0 1 9.859 11.137 47.738 47.738 0 0 0-11.975 31.216l.284-.042c-2.68.49-5.44.751-8.269.76-21.022-.012-38.88-13.566-45.416-32.75 3.102.685 6.287 1.224 9.931 1.654l-.398-.039Zm-9.533-1.614c-.226-.05-.45-.1-.675-.152l.667.129.008.023Zm65.376.815.045-.051-.045.05ZM58 52.836l-.009-.009.01.01Zm-5.59-5.706A140.354 140.354 0 0 0 9.776 20.677l-.952-.332C3.305 28.021 0 37.61 0 47.97v.038c.018 2.3.192 4.539.512 6.733l-.033-.266c3.542.97 7.889 1.823 12.325 2.386l.488.05c16.526 1.797 30.138-1.637 39.12-9.78Zm21.58 11.182a149.73 149.73 0 0 0-10.601-11.7c7.864-10.897 10.059-25.19 6.466-41.155l.267.126C85.46 13.537 95.953 29.542 96 48.007c0 .604-.048 1.247-.097 1.904-.051.688-.104 1.393-.104 2.087h-.042c-8.002.159-15.445 2.596-21.552 6.586l-.215-.272Zm-10.601-11.7-.003-.003.003.003Z"
        />
      </svg>
    ),
  },
  {
    label: "Inicio",
    href: "/",
    icon: (
      <svg
        className="w-6 h-6 transition-opacity duration-300"
        width="20"
        height="20"
        viewBox="0 0 16 16"
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
      >
        <title>Inicio</title>
        <path
          clipRule="evenodd"
          d="M8 0L0 6V8H1V15H4V10H7V15H15V8H16V6L14 4.5V1H11V2.25L8 0ZM9 10H12V13H9V10Z"
        />
      </svg>
    ),
  },
  {
    label: "Live",
    href: "/casino",
    icon: (
      <svg
        className="w-6 h-6 transition-opacity duration-300"
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
      >
        <g>
          <path d="M21,12c0,2.481-1.009,4.731-2.639,6.361l1.414,1.414C21.766,17.783,23,15.033,23,12s-1.234-5.783-3.225-7.775l-1.414,1.414 C19.991,7.269,21,9.519,21,12z" />
          <path d="M3,12c0-2.481,1.009-4.731,2.639-6.361L4.225,4.225C2.234,6.217,1,8.967,1,12s1.234,5.783,3.225,7.775l1.414-1.414 C4.009,16.731,3,14.481,3,12z" />
          <path d="M16.947,7.053l-1.414,1.414C16.439,9.372,17,10.622,17,12s-0.561,2.628-1.466,3.534l1.414,1.414 C18.215,15.68,19,13.93,19,12S18.215,8.32,16.947,7.053z" />
          <path d="M7.053,16.947l1.414-1.414C7.561,14.628,7,13.378,7,12s0.561-2.628,1.466-3.534L7.053,7.053C5.785,8.32,5,10.07,5,12 S5.785,15.68,7.053,16.947z" />
        </g>
        <g>
          <circle cx="12" cy="12" r="3" />
        </g>
      </svg>
    ),
  },
  {
    label: "Minijuego",
    href: "/minigame",
    icon: (
      <svg
        className="w-6 h-6 transition-opacity duration-300"
        width="20"
        height="20"
        viewBox="0 0 24 24"
        fill="currentColor"
        xmlns="http://www.w3.org/2000/svg"
      >
        <title>Minijuego</title>
        <path d="M21 6H3c-1.1 0-2 .9-2 2v8c0 1.1.9 2 2 2h18c1.1 0 2-.9 2-2V8c0-1.1-.9-2-2-2zm0 10H3V8h18v8zM6 15h2v-2H6v2zm3 0h2v-2H9v2zm3 0h2v-2h-2v2zm-6-4h2V9H6v2zm3 0h2V9H9v2zm3 0h2V9h-2v2z" />
      </svg>
    ),
  },
];

const MobileMenu = () => {
  const location = useLocation();
  const [activeItem, setActiveItem] = useState<string | null>(null);
  const [logoAnimate, setLogoAnimate] = useState(false);
  const { themeConfig } = useTheme();

  // Helper function to convert hex to rgba
  const hexToRgba = (hex: string, alpha: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  };

  const headerColor = themeConfig?.modal.headerColor || '#57b3ff';

  // Initialize active item based on current route
  useEffect(() => {
    const currentItem = menuItems.find((item) => {
      if (item.href === "/") {
        return location.pathname === "/";
      }
      return location.pathname.startsWith(item.href);
    });
    if (currentItem) {
      setActiveItem(currentItem.label);
    }
  }, [location.pathname]);

  const isHomeActive = location.pathname === "/";

  const handleItemClick = (itemLabel: string) => {
    setActiveItem(itemLabel);
    // Trigger logo animation when "Inicio" (home) is clicked
    if (itemLabel === "Inicio") {
      setLogoAnimate(true);
      // Reset animation state after animation completes
      setTimeout(() => {
        setLogoAnimate(false);
      }, 1500);
    }
  };

  return (
    <>
      <style>{`
        @keyframes latido {
          0% {
            transform: scale(1);
            filter: brightness(1.7) drop-shadow(0 0 20px ${hexToRgba(headerColor, 0.6)});
          }
          12.5% {
            transform: scale(1.08);
            filter: brightness(1.7) drop-shadow(0 0 22px ${hexToRgba(headerColor, 0.75)});
          }
          25% {
            transform: scale(1.2);
            filter: brightness(1.7) drop-shadow(0 0 25px ${hexToRgba(headerColor, 0.9)});
          }
          37.5% {
            transform: scale(1.32);
            filter: brightness(1.7) drop-shadow(0 0 28px ${hexToRgba(headerColor, 0.95)});
          }
          50% {
            transform: scale(1.4);
            filter: brightness(1.7) drop-shadow(0 0 30px ${hexToRgba(headerColor, 1)});
          }
          62.5% {
            transform: scale(1.32);
            filter: brightness(1.7) drop-shadow(0 0 28px ${hexToRgba(headerColor, 0.95)});
          }
          75% {
            transform: scale(1.2);
            filter: brightness(1.7) drop-shadow(0 0 25px ${hexToRgba(headerColor, 0.9)});
          }
          87.5% {
            transform: scale(1.08);
            filter: brightness(1.7) drop-shadow(0 0 22px ${hexToRgba(headerColor, 0.75)});
          }
          100% {
            transform: scale(1);
            filter: brightness(1.7) drop-shadow(0 0 20px ${hexToRgba(headerColor, 0.6)});
          }
        }
        .logo-latido {
          transform-origin: center center;
          animation: 1.5s cubic-bezier(0.4, 0, 0.2, 1) 0s 1 normal none running latido;
          transition: border 0.3s;
          filter: brightness(1.7) drop-shadow(0 0 20px ${hexToRgba(headerColor, 1)});
        }
      `}</style>
      <nav 
        className="md:hidden fixed bottom-0 left-0 right-0 w-full h-16 z-40"
        style={{
          backgroundColor: themeConfig?.header.backgroundColor || '#030f2f',
        }}
      >
        {/* Logo Section */}
        <div className="absolute -top-3 left-1/2 -translate-x-1/2">
          <img
            src="https://assets.a7a.info/userFiles/bet30vip.ai/cVxQbLppvhTo1NYdI5xot3s4KKj5yM6YnLDj6rm7.png"
            alt="Logo"
            className={cn(
              "effect-logo transition-opacity duration-300 w-16 sm:w-20",
              logoAnimate && "logo-latido"
            )}
            style={{
              filter: isHomeActive && !logoAnimate
                ? `drop-shadow(0 0 25px ${hexToRgba(headerColor, 0.9)})`
                : !logoAnimate
                ? `drop-shadow(0 0 15px ${hexToRgba(headerColor, 0.6)})`
                : undefined
            }}
          />
        </div>
      

      {/* Menu Items */}
      <div className="flex gap-5 items-center justify-around px-2 max-w-[500px] mx-auto min-h-16">
        {menuItems.map((item) => {
          const active = activeItem === item.label;
          return (
            <Link
              key={item.label}
              to={item.href}
              onClick={() => handleItemClick(item.label)}
              className={cn(
                "flex flex-col items-center justify-center relative transition-colors min-w-0 flex-1 min-h-16 w-20",
                active ? "" : "text-white"
              )}
              style={{
                color: active ? headerColor : undefined,
                borderTop: active && item.label !== "Inicio" ? `4px solid ${headerColor}` : undefined,
              }}
            >
              {/* Icon */}
              <div className="flex items-center justify-center">
                {item.icon}
              </div>
              
              {/* Label */}
              <span className="text-sm font-medium whitespace-nowrap text-white">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
    </>
  );
};

export default MobileMenu;


