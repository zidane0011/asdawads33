export interface ThemeConfig {
  theme: number;
  header: {
    backgroundColor: string;
    textColor: string;
    borderColor: string;
    textHover: string;
    selectedTextColor: string;
  };
  banner: {
    backgroundColor: string;
  };
  logo: {
    image: string;
  };
  favicon: {
    image: string;
  };
  colors: {
    primary: string;
    secondary: string;
    tertiary: string;
    border: string;
  };
  gradient: {
    from: string;
    to: string;
  };
  modal: {
    backgroundColor: string;
    headerColor: string;
    buttonColor: string;
  };
  input: {
    backgroundColor: string;
    borderColor: string;
  };
  scrollbar: {
    track: string;
    thumb: string;
  };
}

export const themeConfigs: ThemeConfig[] = [
  {
    theme: 1,
    header: {
      backgroundColor: '#030f2f',
      textColor: '#ffffff',
      borderColor: '#27287e',
      textHover: '#e0e0e0',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#000719',
    },
    logo: {
      image: '/logo_theme1.png',
    },
    favicon: {
      image: '/favicon_theme1.png',
    },
    colors: {
      primary: '#000719',
      secondary: '#030f2f',
      tertiary: '#212c36',
      border: '#27287e',
    },
    gradient: {
      from: '#021b79',
      to: '#0575e6',
    },
    modal: {
      backgroundColor: '#000719',
      headerColor: '#5b9eeb',
      buttonColor: '#030f2f',
    },
    input: {
      backgroundColor: '#030f2f',
      borderColor: '#27287e',
    },
    scrollbar: {
      track: '#212c36',
      thumb: '#0a37a2',
    },
  },
  {
    theme: 2,
    header: {
      backgroundColor: '#252536',
      textColor: '#ffffff',
      borderColor: '#4a5166',
      textHover: '#636363',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#0f0f1e',
    },
    logo: {
      image: '/logo_theme2.png',
    },
    favicon: {
      image: '/favicon_theme2.png',
    },
    colors: {
      primary: '#0b0b11',
      secondary: '#0f0f15',
      tertiary: '#77787c',
      border: '#77787c',
    },
    gradient: {
      from: '#50046a',
      to: '#b05b08',
    },
    modal: {
      backgroundColor: '#0f0f10',
      headerColor: '#bebeff',
      buttonColor: '#202226',
    },
    input: {
      backgroundColor: '#1e1e1e',
      borderColor: '#625b58',
    },
    scrollbar: {
      track: '#181c26',
      thumb: '#5b5c60',
    },
  },
  {
    theme: 3,
    header: {
      backgroundColor: '#35025a',
      textColor: '#ffffff',
      borderColor: '#9c00ff',
      textHover: '#fafa02',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#2d0748',
    },
    logo: {
      image: '/logo_theme1.png',
    },
    favicon: {
      image: '/favicon_theme1.png',
    },
    colors: {
      primary: '#18002a',
      secondary: '#22013a',
      tertiary: '#35025a',
      border: '#4d4d6c',
    },
    gradient: {
      from: '#560050',
      to: '#c200ff',
    },
    modal: {
      backgroundColor: '#150124',
      headerColor: '#b294ff',
      buttonColor: '#220036',
    },
    input: {
      backgroundColor: '#160024',
      borderColor: '#39004c',
    },
    scrollbar: {
      track: '#2d0048',
      thumb: '#460078',
    },
  },
  {
    theme: 4,
    header: {
      backgroundColor: '#012a05',
      textColor: '#ffffff',
      borderColor: '#005a0c',
      textHover: '#00cc33',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#001a03',
    },
    logo: {
      image: '/logo_theme1.png',
    },
    favicon: {
      image: '/favicon_theme1.png',
    },
    colors: {
      primary: '#000901',
      secondary: '#000f02',
      tertiary: '#004209',
      border: '#005a0c',
    },
    gradient: {
      from: '#0690c2',
      to: '#a6a500',
    },
    modal: {
      backgroundColor: '#001100',
      headerColor: '#ffdd03',
      buttonColor: '#00280e',
    },
    input: {
      backgroundColor: '#011303',
      borderColor: '#4c4801',
    },
    scrollbar: {
      track: '#002d05',
      thumb: '#005a0c',
    },
  },
  {
    theme: 5,
    header: {
      backgroundColor: '#660300',
      textColor: '#ffffff',
      borderColor: '#c03000',
      textHover: '#e0e0e0',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#2e0903',
    },
    logo: {
      image: '/logo_theme1.png',
    },
    favicon: {
      image: '/favicon_theme1.png',
    },
    colors: {
      primary: '#2e0903',
      secondary: '#3d0f0a',
      tertiary: '#4d1f1a',
      border: '#5d2f2a',
    },
    gradient: {
      from: '#940000',
      to: '#ca8005',
    },
    modal: {
      backgroundColor: '#000000',
      headerColor: '#eb5b5b',
      buttonColor: '#2f0303',
    },
    input: {
      backgroundColor: '#1e1e1e',
      borderColor: '#625b58',
    },
    scrollbar: {
      track: '#4d1f1a',
      thumb: '#ba3a2c',
    },
  },
  {
    theme: 6,
    header: {
      backgroundColor: '#1a1a1a',
      textColor: '#ffffff',
      borderColor: '#948b27',
      textHover: '#FFD700',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#000000',
    },
    logo: {
      image: '/logo_theme1.png',
    },
    favicon: {
      image: '/favicon_theme1.png',
    },
    colors: {
      primary: '#000000',
      secondary: '#1a1a1a',
      tertiary: '#2d2d2d',
      border: '#ffda29',
    },
    gradient: {
      from: '#e8d600',
      to: '#726201',
    },
    modal: {
      backgroundColor: '#0f0f0f',
      headerColor: '#f8df57',
      buttonColor: '#424036',
    },
    input: {
      backgroundColor: '#1a1a1a',
      borderColor: '#333333',
    },
    scrollbar: {
      track: '#1a1a1a',
      thumb: '#947d01',
    },
  },
  {
    theme: 7,
    header: {
      backgroundColor: '#aa9200',
      textColor: '#3e0b0b',
      borderColor: '#500202',
      textHover: '#1a1a1a',
      selectedTextColor: '#ffffff',
    },
    banner: {
      backgroundColor: '#FFD700',
    },
    logo: {
      image: '/logo_theme1.png',
    },
    favicon: {
      image: '/favicon_theme1.png',
    },
    colors: {
      primary: '#726201',
      secondary: '#7e6b02',
      tertiary: '#726201',
      border: '#726201',
    },
    gradient: {
      from: '#604141',
      to: '#e8e143',
    },
    modal: {
      backgroundColor: '#240000',
      headerColor: '#803b3b',
      buttonColor: '#c6a800',
    },
    input: {
      backgroundColor: '#FFE44D',
      borderColor: '#000000',
    },
    scrollbar: {
      track: '#867b3f',
      thumb: '#523131',
    },
  },
];

export const getThemeConfig = (themeNumber: number): ThemeConfig => {
  const config = themeConfigs.find((config) => config.theme === themeNumber);
  return config || themeConfigs[0]; // Default to theme 1 if not found
};

