import { Play } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useLoginModal } from "@/hooks/useLoginModal";
import { useTheme } from "@/hooks/useTheme";

interface GameCardProps {
  title: string;
  imageUrl: string;
  gameCode?: string;
  vendorCode?: string;
}

const GameCard = ({ title, imageUrl, gameCode, vendorCode }: GameCardProps) => {
  const navigate = useNavigate();
  const { accessToken, user } = useAuth();
  const { openLoginModal } = useLoginModal();
  const { themeConfig } = useTheme();

  const handleClick = () => {
    if (!gameCode || !vendorCode) {
      return;
    }

    // Check if user is logged in
    if (accessToken || user) {
      // User is logged in - navigate to game detail page
      navigate(`/game?game_code=${encodeURIComponent(gameCode)}&vendor_code=${encodeURIComponent(vendorCode)}`);
    } else {
      // User is not logged in - open login modal with game info
      openLoginModal(gameCode, vendorCode);
    }
  };

  return (
    <div className="group flex-shrink-0 w-full cursor-pointer" onClick={handleClick}>
      {/* Card Container */}
      <div 
        className="relative aspect-square rounded-xl overflow-hidden bg-card border-2 transition-all duration-300 group-hover:shadow-[0_0_20px_hsl(var(--bet-blue)/0.3)] group-hover:brightness-110"
        style={{
          borderColor: themeConfig?.header.borderColor || '#27287e',
        }}
      >
        {/* Game Image */}
        <img
          src={imageUrl}
          alt={title}
          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
        />
        
        {/* Hover Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
          <div className="w-16 h-16 rounded-full bg-primary/90 flex items-center justify-center shadow-lg shadow-primary/30 transform scale-75 group-hover:scale-100 transition-transform duration-300">
            <Play className="w-8 h-8 text-white fill-white ml-1" />
          </div>
        </div>
      </div>
      
      {/* Game Title */}
      <p 
        className="mt-2 text-xs md:text-sm text-center transition-colors duration-200 truncate px-1"
        style={{ color: themeConfig?.header.textColor || '#FFFFFF' }}
      >
        {title}
      </p>
    </div>
  );
};

export default GameCard;
